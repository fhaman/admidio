-- Admidio v4.2.14 (https://www.admidio.org)
-- Backup vom 19.12.2023 um 8:57:57

-- Datenbank: admidio

-- Benutzer:in: Founaboui Haman

SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE `admidio_roles` (
  `rol_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rol_cat_id` int(10) unsigned NOT NULL,
  `rol_lst_id` int(10) unsigned DEFAULT NULL,
  `rol_uuid` varchar(36) NOT NULL,
  `rol_name` varchar(100) NOT NULL,
  `rol_description` varchar(4000) DEFAULT NULL,
  `rol_assign_roles` tinyint(1) NOT NULL DEFAULT 0,
  `rol_approve_users` tinyint(1) NOT NULL DEFAULT 0,
  `rol_announcements` tinyint(1) NOT NULL DEFAULT 0,
  `rol_dates` tinyint(1) NOT NULL DEFAULT 0,
  `rol_documents_files` tinyint(1) NOT NULL DEFAULT 0,
  `rol_edit_user` tinyint(1) NOT NULL DEFAULT 0,
  `rol_guestbook` tinyint(1) NOT NULL DEFAULT 0,
  `rol_guestbook_comments` tinyint(1) NOT NULL DEFAULT 0,
  `rol_mail_to_all` tinyint(1) NOT NULL DEFAULT 0,
  `rol_mail_this_role` smallint(6) NOT NULL DEFAULT 0,
  `rol_photo` tinyint(1) NOT NULL DEFAULT 0,
  `rol_profile` tinyint(1) NOT NULL DEFAULT 0,
  `rol_weblinks` tinyint(1) NOT NULL DEFAULT 0,
  `rol_all_lists_view` tinyint(1) NOT NULL DEFAULT 0,
  `rol_default_registration` tinyint(1) NOT NULL DEFAULT 0,
  `rol_leader_rights` smallint(6) NOT NULL DEFAULT 0,
  `rol_view_memberships` smallint(6) NOT NULL DEFAULT 0,
  `rol_view_members_profiles` smallint(6) NOT NULL DEFAULT 0,
  `rol_start_date` date DEFAULT NULL,
  `rol_start_time` time DEFAULT NULL,
  `rol_end_date` date DEFAULT NULL,
  `rol_end_time` time DEFAULT NULL,
  `rol_weekday` smallint(6) DEFAULT NULL,
  `rol_location` varchar(100) DEFAULT NULL,
  `rol_max_members` int(11) DEFAULT NULL,
  `rol_cost` float DEFAULT NULL,
  `rol_cost_period` smallint(6) DEFAULT NULL,
  `rol_usr_id_create` int(10) unsigned DEFAULT NULL,
  `rol_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `rol_usr_id_change` int(10) unsigned DEFAULT NULL,
  `rol_timestamp_change` timestamp NULL DEFAULT NULL,
  `rol_valid` tinyint(1) NOT NULL DEFAULT 1,
  `rol_system` tinyint(1) NOT NULL DEFAULT 0,
  `rol_administrator` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rol_id`),
  UNIQUE KEY `admidio_idx_rol_uuid` (`rol_uuid`),
  KEY `admidio_fk_rol_cat` (`rol_cat_id`),
  KEY `admidio_fk_rol_lst_id` (`rol_lst_id`),
  KEY `admidio_fk_rol_usr_create` (`rol_usr_id_create`),
  KEY `admidio_fk_rol_usr_change` (`rol_usr_id_change`),
  CONSTRAINT `admidio_fk_rol_cat` FOREIGN KEY (`rol_cat_id`) REFERENCES `admidio_categories` (`cat_id`),
  CONSTRAINT `admidio_fk_rol_lst_id` FOREIGN KEY (`rol_lst_id`) REFERENCES `admidio_lists` (`lst_id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `admidio_fk_rol_usr_change` FOREIGN KEY (`rol_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_rol_usr_create` FOREIGN KEY (`rol_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_auto_login` (
  `atl_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `atl_auto_login_id` varchar(255) NOT NULL,
  `atl_session_id` varchar(255) NOT NULL,
  `atl_org_id` int(10) unsigned NOT NULL,
  `atl_usr_id` int(10) unsigned NOT NULL,
  `atl_last_login` timestamp NULL DEFAULT NULL,
  `atl_number_invalid` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`atl_id`),
  KEY `admidio_fk_atl_usr` (`atl_usr_id`),
  KEY `admidio_fk_atl_org` (`atl_org_id`),
  CONSTRAINT `admidio_fk_atl_org` FOREIGN KEY (`atl_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_atl_usr` FOREIGN KEY (`atl_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_menu` (
  `men_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `men_men_id_parent` int(10) unsigned DEFAULT NULL,
  `men_com_id` int(10) unsigned DEFAULT NULL,
  `men_uuid` varchar(36) NOT NULL,
  `men_name_intern` varchar(255) DEFAULT NULL,
  `men_name` varchar(255) DEFAULT NULL,
  `men_description` varchar(4000) DEFAULT NULL,
  `men_node` tinyint(1) NOT NULL DEFAULT 0,
  `men_order` int(10) unsigned DEFAULT NULL,
  `men_standard` tinyint(1) NOT NULL DEFAULT 0,
  `men_url` varchar(2000) DEFAULT NULL,
  `men_icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`men_id`),
  UNIQUE KEY `admidio_idx_men_uuid` (`men_uuid`),
  KEY `admidio_idx_men_men_id_parent` (`men_men_id_parent`),
  KEY `admidio_fk_men_com_id` (`men_com_id`),
  CONSTRAINT `admidio_fk_men_com_id` FOREIGN KEY (`men_com_id`) REFERENCES `admidio_components` (`com_id`),
  CONSTRAINT `admidio_fk_men_men_parent` FOREIGN KEY (`men_men_id_parent`) REFERENCES `admidio_menu` (`men_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_categories` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cat_org_id` int(10) unsigned DEFAULT NULL,
  `cat_uuid` varchar(36) NOT NULL,
  `cat_type` varchar(10) NOT NULL,
  `cat_name_intern` varchar(110) NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_system` tinyint(1) NOT NULL DEFAULT 0,
  `cat_default` tinyint(1) NOT NULL DEFAULT 0,
  `cat_sequence` smallint(6) NOT NULL,
  `cat_usr_id_create` int(10) unsigned DEFAULT NULL,
  `cat_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `cat_usr_id_change` int(10) unsigned DEFAULT NULL,
  `cat_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`cat_id`),
  UNIQUE KEY `admidio_idx_cat_uuid` (`cat_uuid`),
  KEY `admidio_fk_cat_org` (`cat_org_id`),
  KEY `admidio_fk_cat_usr_create` (`cat_usr_id_create`),
  KEY `admidio_fk_cat_usr_change` (`cat_usr_id_change`),
  CONSTRAINT `admidio_fk_cat_org` FOREIGN KEY (`cat_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_cat_usr_change` FOREIGN KEY (`cat_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_cat_usr_create` FOREIGN KEY (`cat_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_messages_recipients` (
  `msr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msr_msg_id` int(10) unsigned NOT NULL,
  `msr_rol_id` int(10) unsigned DEFAULT NULL,
  `msr_usr_id` int(10) unsigned DEFAULT NULL,
  `msr_role_mode` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`msr_id`),
  KEY `admidio_fk_msr_msg_id` (`msr_msg_id`),
  KEY `admidio_fk_msr_rol_id` (`msr_rol_id`),
  KEY `admidio_fk_msr_usr_id` (`msr_usr_id`),
  CONSTRAINT `admidio_fk_msr_msg_id` FOREIGN KEY (`msr_msg_id`) REFERENCES `admidio_messages` (`msg_id`),
  CONSTRAINT `admidio_fk_msr_rol_id` FOREIGN KEY (`msr_rol_id`) REFERENCES `admidio_roles` (`rol_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_msr_usr_id` FOREIGN KEY (`msr_usr_id`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_texts` (
  `txt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `txt_org_id` int(10) unsigned NOT NULL,
  `txt_name` varchar(30) NOT NULL,
  `txt_text` text DEFAULT NULL,
  PRIMARY KEY (`txt_id`),
  KEY `admidio_fk_txt_org` (`txt_org_id`),
  CONSTRAINT `admidio_fk_txt_org` FOREIGN KEY (`txt_org_id`) REFERENCES `admidio_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_messages_attachments` (
  `msa_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msa_msg_id` int(10) unsigned NOT NULL,
  `msa_file_name` varchar(256) NOT NULL,
  `msa_original_file_name` varchar(256) NOT NULL,
  PRIMARY KEY (`msa_id`),
  KEY `admidio_fk_msa_msg_id` (`msa_msg_id`),
  CONSTRAINT `admidio_fk_msa_msg_id` FOREIGN KEY (`msa_msg_id`) REFERENCES `admidio_messages` (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_category_report` (
  `crt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crt_org_id` int(10) unsigned DEFAULT NULL,
  `crt_name` varchar(100) NOT NULL,
  `crt_col_fields` text DEFAULT NULL,
  `crt_selection_role` varchar(100) DEFAULT NULL,
  `crt_selection_cat` varchar(100) DEFAULT NULL,
  `crt_number_col` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`crt_id`),
  KEY `admidio_fk_crt_org` (`crt_org_id`),
  CONSTRAINT `admidio_fk_crt_org` FOREIGN KEY (`crt_org_id`) REFERENCES `admidio_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_files` (
  `fil_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fil_fol_id` int(10) unsigned NOT NULL,
  `fil_uuid` varchar(36) NOT NULL,
  `fil_name` varchar(255) NOT NULL,
  `fil_description` text DEFAULT NULL,
  `fil_locked` tinyint(1) NOT NULL DEFAULT 0,
  `fil_counter` int(11) DEFAULT NULL,
  `fil_usr_id` int(10) unsigned DEFAULT NULL,
  `fil_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`fil_id`),
  UNIQUE KEY `admidio_idx_fil_uuid` (`fil_uuid`),
  KEY `admidio_fk_fil_fol` (`fil_fol_id`),
  KEY `admidio_fk_fil_usr` (`fil_usr_id`),
  CONSTRAINT `admidio_fk_fil_fol` FOREIGN KEY (`fil_fol_id`) REFERENCES `admidio_folders` (`fol_id`),
  CONSTRAINT `admidio_fk_fil_usr` FOREIGN KEY (`fil_usr_id`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_organizations` (
  `org_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `org_uuid` varchar(36) NOT NULL,
  `org_shortname` varchar(10) NOT NULL,
  `org_longname` varchar(60) NOT NULL,
  `org_org_id_parent` int(10) unsigned DEFAULT NULL,
  `org_homepage` varchar(60) NOT NULL,
  PRIMARY KEY (`org_id`),
  UNIQUE KEY `admidio_idx_org_shortname` (`org_shortname`),
  UNIQUE KEY `admidio_idx_org_uuid` (`org_uuid`),
  KEY `admidio_fk_org_org_parent` (`org_org_id_parent`),
  CONSTRAINT `admidio_fk_org_org_parent` FOREIGN KEY (`org_org_id_parent`) REFERENCES `admidio_organizations` (`org_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_plugin_preferences` (
  `plp_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `plp_org_id` int(10) unsigned NOT NULL,
  `plp_name` varchar(255) NOT NULL,
  `plp_value` text DEFAULT NULL,
  PRIMARY KEY (`plp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_users` (
  `usr_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usr_uuid` varchar(36) NOT NULL,
  `usr_login_name` varchar(254) DEFAULT NULL,
  `usr_password` varchar(255) DEFAULT NULL,
  `usr_photo` blob DEFAULT NULL,
  `usr_text` text DEFAULT NULL,
  `usr_pw_reset_id` varchar(50) DEFAULT NULL,
  `usr_pw_reset_timestamp` timestamp NULL DEFAULT NULL,
  `usr_last_login` timestamp NULL DEFAULT NULL,
  `usr_actual_login` timestamp NULL DEFAULT NULL,
  `usr_number_login` int(11) NOT NULL DEFAULT 0,
  `usr_date_invalid` timestamp NULL DEFAULT NULL,
  `usr_number_invalid` smallint(6) NOT NULL DEFAULT 0,
  `usr_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usr_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `usr_usr_id_change` int(10) unsigned DEFAULT NULL,
  `usr_timestamp_change` timestamp NULL DEFAULT NULL,
  `usr_valid` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`usr_id`),
  UNIQUE KEY `admidio_idx_usr_uuid` (`usr_uuid`),
  UNIQUE KEY `admidio_idx_usr_login_name` (`usr_login_name`),
  KEY `admidio_fk_usr_usr_create` (`usr_usr_id_create`),
  KEY `admidio_fk_usr_usr_change` (`usr_usr_id_change`),
  CONSTRAINT `admidio_fk_usr_usr_change` FOREIGN KEY (`usr_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_usr_usr_create` FOREIGN KEY (`usr_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_user_data` (
  `usd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usd_usr_id` int(10) unsigned NOT NULL,
  `usd_usf_id` int(10) unsigned NOT NULL,
  `usd_value` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`usd_id`),
  UNIQUE KEY `admidio_idx_usd_usr_usf_id` (`usd_usr_id`,`usd_usf_id`),
  KEY `admidio_fk_usd_usf` (`usd_usf_id`),
  CONSTRAINT `admidio_fk_usd_usf` FOREIGN KEY (`usd_usf_id`) REFERENCES `admidio_user_fields` (`usf_id`),
  CONSTRAINT `admidio_fk_usd_usr` FOREIGN KEY (`usd_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_components` (
  `com_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `com_type` varchar(10) NOT NULL,
  `com_name` varchar(255) NOT NULL,
  `com_name_intern` varchar(255) NOT NULL,
  `com_version` varchar(10) NOT NULL,
  `com_beta` smallint(6) NOT NULL DEFAULT 0,
  `com_update_step` int(11) NOT NULL DEFAULT 0,
  `com_update_completed` tinyint(1) NOT NULL DEFAULT 1,
  `com_timestamp_installed` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`com_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_preferences` (
  `prf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prf_org_id` int(10) unsigned NOT NULL,
  `prf_name` varchar(50) NOT NULL,
  `prf_value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`prf_id`),
  UNIQUE KEY `admidio_idx_prf_org_id_name` (`prf_org_id`,`prf_name`),
  CONSTRAINT `admidio_fk_prf_org` FOREIGN KEY (`prf_org_id`) REFERENCES `admidio_organizations` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=132 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_lists` (
  `lst_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lst_org_id` int(10) unsigned NOT NULL,
  `lst_usr_id` int(10) unsigned NOT NULL,
  `lst_uuid` varchar(36) NOT NULL,
  `lst_name` varchar(255) DEFAULT NULL,
  `lst_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `lst_global` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`lst_id`),
  UNIQUE KEY `admidio_idx_lst_uuid` (`lst_uuid`),
  KEY `admidio_fk_lst_usr` (`lst_usr_id`),
  KEY `admidio_fk_lst_org` (`lst_org_id`),
  CONSTRAINT `admidio_fk_lst_org` FOREIGN KEY (`lst_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_lst_usr` FOREIGN KEY (`lst_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_messages` (
  `msg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msg_uuid` varchar(36) NOT NULL,
  `msg_type` varchar(10) NOT NULL,
  `msg_subject` varchar(256) NOT NULL,
  `msg_usr_id_sender` int(10) unsigned NOT NULL,
  `msg_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `msg_read` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`msg_id`),
  UNIQUE KEY `admidio_idx_msg_uuid` (`msg_uuid`),
  KEY `admidio_fk_msg_usr_sender` (`msg_usr_id_sender`),
  CONSTRAINT `admidio_fk_msg_usr_sender` FOREIGN KEY (`msg_usr_id_sender`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_guestbook` (
  `gbo_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbo_org_id` int(10) unsigned NOT NULL,
  `gbo_uuid` varchar(36) NOT NULL,
  `gbo_name` varchar(60) NOT NULL,
  `gbo_text` text NOT NULL,
  `gbo_email` varchar(254) DEFAULT NULL,
  `gbo_homepage` varchar(50) DEFAULT NULL,
  `gbo_ip_address` varchar(39) NOT NULL,
  `gbo_locked` tinyint(1) NOT NULL DEFAULT 0,
  `gbo_usr_id_create` int(10) unsigned DEFAULT NULL,
  `gbo_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `gbo_usr_id_change` int(10) unsigned DEFAULT NULL,
  `gbo_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`gbo_id`),
  UNIQUE KEY `admidio_idx_gbo_uuid` (`gbo_uuid`),
  KEY `admidio_fk_gbo_org` (`gbo_org_id`),
  KEY `admidio_fk_gbo_usr_create` (`gbo_usr_id_create`),
  KEY `admidio_fk_gbo_usr_change` (`gbo_usr_id_change`),
  CONSTRAINT `admidio_fk_gbo_org` FOREIGN KEY (`gbo_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_gbo_usr_change` FOREIGN KEY (`gbo_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_gbo_usr_create` FOREIGN KEY (`gbo_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_roles_rights_data` (
  `rrd_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rrd_ror_id` int(10) unsigned NOT NULL,
  `rrd_rol_id` int(10) unsigned NOT NULL,
  `rrd_object_id` int(10) unsigned NOT NULL,
  `rrd_usr_id_create` int(10) unsigned DEFAULT NULL,
  `rrd_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`rrd_id`),
  UNIQUE KEY `admidio_idx_rrd_ror_rol_object_id` (`rrd_ror_id`,`rrd_rol_id`,`rrd_object_id`),
  KEY `admidio_fk_rrd_rol` (`rrd_rol_id`),
  KEY `admidio_fk_rrd_usr_create` (`rrd_usr_id_create`),
  CONSTRAINT `admidio_fk_rrd_rol` FOREIGN KEY (`rrd_rol_id`) REFERENCES `admidio_roles` (`rol_id`),
  CONSTRAINT `admidio_fk_rrd_ror` FOREIGN KEY (`rrd_ror_id`) REFERENCES `admidio_roles_rights` (`ror_id`),
  CONSTRAINT `admidio_fk_rrd_usr_create` FOREIGN KEY (`rrd_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_guestbook_comments` (
  `gbc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `gbc_gbo_id` int(10) unsigned NOT NULL,
  `gbc_uuid` varchar(36) NOT NULL,
  `gbc_name` varchar(60) NOT NULL,
  `gbc_text` text NOT NULL,
  `gbc_email` varchar(254) DEFAULT NULL,
  `gbc_ip_address` varchar(39) NOT NULL,
  `gbc_locked` tinyint(1) NOT NULL DEFAULT 0,
  `gbc_usr_id_create` int(10) unsigned DEFAULT NULL,
  `gbc_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `gbc_usr_id_change` int(10) unsigned DEFAULT NULL,
  `gbc_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`gbc_id`),
  UNIQUE KEY `admidio_idx_gbc_uuid` (`gbc_uuid`),
  KEY `admidio_fk_gbc_gbo` (`gbc_gbo_id`),
  KEY `admidio_fk_gbc_usr_create` (`gbc_usr_id_create`),
  KEY `admidio_fk_gbc_usr_change` (`gbc_usr_id_change`),
  CONSTRAINT `admidio_fk_gbc_gbo` FOREIGN KEY (`gbc_gbo_id`) REFERENCES `admidio_guestbook` (`gbo_id`),
  CONSTRAINT `admidio_fk_gbc_usr_change` FOREIGN KEY (`gbc_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_gbc_usr_create` FOREIGN KEY (`gbc_usr_id_create`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_folders` (
  `fol_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fol_org_id` int(10) unsigned NOT NULL,
  `fol_fol_id_parent` int(10) unsigned DEFAULT NULL,
  `fol_uuid` varchar(36) NOT NULL,
  `fol_type` varchar(10) NOT NULL,
  `fol_name` varchar(255) NOT NULL,
  `fol_description` text DEFAULT NULL,
  `fol_path` varchar(255) NOT NULL,
  `fol_locked` tinyint(1) NOT NULL DEFAULT 0,
  `fol_public` tinyint(1) NOT NULL DEFAULT 0,
  `fol_usr_id` int(10) unsigned DEFAULT NULL,
  `fol_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`fol_id`),
  UNIQUE KEY `admidio_idx_fol_uuid` (`fol_uuid`),
  KEY `admidio_fk_fol_org` (`fol_org_id`),
  KEY `admidio_fk_fol_fol_parent` (`fol_fol_id_parent`),
  KEY `admidio_fk_fol_usr` (`fol_usr_id`),
  CONSTRAINT `admidio_fk_fol_fol_parent` FOREIGN KEY (`fol_fol_id_parent`) REFERENCES `admidio_folders` (`fol_id`),
  CONSTRAINT `admidio_fk_fol_org` FOREIGN KEY (`fol_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_fol_usr` FOREIGN KEY (`fol_usr_id`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_dates` (
  `dat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `dat_cat_id` int(10) unsigned NOT NULL,
  `dat_rol_id` int(10) unsigned DEFAULT NULL,
  `dat_room_id` int(10) unsigned DEFAULT NULL,
  `dat_uuid` varchar(36) NOT NULL,
  `dat_begin` timestamp NULL DEFAULT NULL,
  `dat_end` timestamp NULL DEFAULT NULL,
  `dat_all_day` tinyint(1) NOT NULL DEFAULT 0,
  `dat_headline` varchar(100) NOT NULL,
  `dat_description` text DEFAULT NULL,
  `dat_highlight` tinyint(1) NOT NULL DEFAULT 0,
  `dat_location` varchar(100) DEFAULT NULL,
  `dat_country` varchar(100) DEFAULT NULL,
  `dat_deadline` timestamp NULL DEFAULT NULL,
  `dat_max_members` int(11) NOT NULL DEFAULT 0,
  `dat_usr_id_create` int(10) unsigned DEFAULT NULL,
  `dat_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `dat_usr_id_change` int(10) unsigned DEFAULT NULL,
  `dat_timestamp_change` timestamp NULL DEFAULT NULL,
  `dat_allow_comments` tinyint(1) NOT NULL DEFAULT 0,
  `dat_additional_guests` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`dat_id`),
  UNIQUE KEY `admidio_idx_dat_uuid` (`dat_uuid`),
  KEY `admidio_fk_dat_cat` (`dat_cat_id`),
  KEY `admidio_fk_dat_rol` (`dat_rol_id`),
  KEY `admidio_fk_dat_room` (`dat_room_id`),
  KEY `admidio_fk_dat_usr_create` (`dat_usr_id_create`),
  KEY `admidio_fk_dat_usr_change` (`dat_usr_id_change`),
  CONSTRAINT `admidio_fk_dat_cat` FOREIGN KEY (`dat_cat_id`) REFERENCES `admidio_categories` (`cat_id`),
  CONSTRAINT `admidio_fk_dat_rol` FOREIGN KEY (`dat_rol_id`) REFERENCES `admidio_roles` (`rol_id`),
  CONSTRAINT `admidio_fk_dat_room` FOREIGN KEY (`dat_room_id`) REFERENCES `admidio_rooms` (`room_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_dat_usr_change` FOREIGN KEY (`dat_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_dat_usr_create` FOREIGN KEY (`dat_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_members` (
  `mem_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mem_rol_id` int(10) unsigned NOT NULL,
  `mem_usr_id` int(10) unsigned NOT NULL,
  `mem_uuid` varchar(36) NOT NULL,
  `mem_begin` date NOT NULL,
  `mem_end` date NOT NULL DEFAULT '9999-12-31',
  `mem_leader` tinyint(1) NOT NULL DEFAULT 0,
  `mem_usr_id_create` int(10) unsigned DEFAULT NULL,
  `mem_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `mem_usr_id_change` int(10) unsigned DEFAULT NULL,
  `mem_timestamp_change` timestamp NULL DEFAULT NULL,
  `mem_approved` int(10) unsigned DEFAULT NULL,
  `mem_comment` varchar(4000) DEFAULT NULL,
  `mem_count_guests` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`mem_id`),
  UNIQUE KEY `admidio_idx_mem_uuid` (`mem_uuid`),
  KEY `admidio_idx_mem_rol_usr_id` (`mem_rol_id`,`mem_usr_id`),
  KEY `admidio_fk_mem_usr` (`mem_usr_id`),
  KEY `admidio_fk_mem_usr_create` (`mem_usr_id_create`),
  KEY `admidio_fk_mem_usr_change` (`mem_usr_id_change`),
  CONSTRAINT `admidio_fk_mem_rol` FOREIGN KEY (`mem_rol_id`) REFERENCES `admidio_roles` (`rol_id`),
  CONSTRAINT `admidio_fk_mem_usr` FOREIGN KEY (`mem_usr_id`) REFERENCES `admidio_users` (`usr_id`),
  CONSTRAINT `admidio_fk_mem_usr_change` FOREIGN KEY (`mem_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_mem_usr_create` FOREIGN KEY (`mem_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_photos` (
  `pho_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pho_org_id` int(10) unsigned NOT NULL,
  `pho_pho_id_parent` int(10) unsigned DEFAULT NULL,
  `pho_uuid` varchar(36) NOT NULL,
  `pho_quantity` int(10) unsigned NOT NULL DEFAULT 0,
  `pho_name` varchar(50) NOT NULL,
  `pho_begin` date NOT NULL,
  `pho_end` date NOT NULL,
  `pho_description` varchar(4000) DEFAULT NULL,
  `pho_photographers` varchar(100) DEFAULT NULL,
  `pho_locked` tinyint(1) NOT NULL DEFAULT 0,
  `pho_usr_id_create` int(10) unsigned DEFAULT NULL,
  `pho_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `pho_usr_id_change` int(10) unsigned DEFAULT NULL,
  `pho_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`pho_id`),
  UNIQUE KEY `admidio_idx_pho_uuid` (`pho_uuid`),
  KEY `admidio_fk_pho_pho_parent` (`pho_pho_id_parent`),
  KEY `admidio_fk_pho_org` (`pho_org_id`),
  KEY `admidio_fk_pho_usr_create` (`pho_usr_id_create`),
  KEY `admidio_fk_pho_usr_change` (`pho_usr_id_change`),
  CONSTRAINT `admidio_fk_pho_org` FOREIGN KEY (`pho_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_pho_pho_parent` FOREIGN KEY (`pho_pho_id_parent`) REFERENCES `admidio_photos` (`pho_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_pho_usr_change` FOREIGN KEY (`pho_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_pho_usr_create` FOREIGN KEY (`pho_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_role_dependencies` (
  `rld_rol_id_parent` int(10) unsigned NOT NULL,
  `rld_rol_id_child` int(10) unsigned NOT NULL,
  `rld_comment` text DEFAULT NULL,
  `rld_usr_id` int(10) unsigned DEFAULT NULL,
  `rld_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`rld_rol_id_parent`,`rld_rol_id_child`),
  KEY `admidio_fk_rld_rol_child` (`rld_rol_id_child`),
  KEY `admidio_fk_rld_usr` (`rld_usr_id`),
  CONSTRAINT `admidio_fk_rld_rol_child` FOREIGN KEY (`rld_rol_id_child`) REFERENCES `admidio_roles` (`rol_id`),
  CONSTRAINT `admidio_fk_rld_rol_parent` FOREIGN KEY (`rld_rol_id_parent`) REFERENCES `admidio_roles` (`rol_id`),
  CONSTRAINT `admidio_fk_rld_usr` FOREIGN KEY (`rld_usr_id`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_sessions` (
  `ses_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ses_usr_id` int(10) unsigned DEFAULT NULL,
  `ses_org_id` int(10) unsigned NOT NULL,
  `ses_session_id` varchar(255) NOT NULL,
  `ses_begin` timestamp NULL DEFAULT NULL,
  `ses_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `ses_ip_address` varchar(39) NOT NULL,
  `ses_binary` blob DEFAULT NULL,
  `ses_reload` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `admidio_idx_session_id` (`ses_session_id`),
  KEY `admidio_fk_ses_org` (`ses_org_id`),
  KEY `admidio_fk_ses_usr` (`ses_usr_id`),
  CONSTRAINT `admidio_fk_ses_org` FOREIGN KEY (`ses_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_ses_usr` FOREIGN KEY (`ses_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_list_columns` (
  `lsc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lsc_lst_id` int(10) unsigned NOT NULL,
  `lsc_number` smallint(6) NOT NULL,
  `lsc_usf_id` int(10) unsigned DEFAULT NULL,
  `lsc_special_field` varchar(255) DEFAULT NULL,
  `lsc_sort` varchar(5) DEFAULT NULL,
  `lsc_filter` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`lsc_id`),
  KEY `admidio_fk_lsc_lst` (`lsc_lst_id`),
  KEY `admidio_fk_lsc_usf` (`lsc_usf_id`),
  CONSTRAINT `admidio_fk_lsc_lst` FOREIGN KEY (`lsc_lst_id`) REFERENCES `admidio_lists` (`lst_id`),
  CONSTRAINT `admidio_fk_lsc_usf` FOREIGN KEY (`lsc_usf_id`) REFERENCES `admidio_user_fields` (`usf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_registrations` (
  `reg_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `reg_org_id` int(10) unsigned NOT NULL,
  `reg_usr_id` int(10) unsigned NOT NULL,
  `reg_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`reg_id`),
  KEY `admidio_fk_reg_org` (`reg_org_id`),
  KEY `admidio_fk_reg_usr` (`reg_usr_id`),
  CONSTRAINT `admidio_fk_reg_org` FOREIGN KEY (`reg_org_id`) REFERENCES `admidio_organizations` (`org_id`),
  CONSTRAINT `admidio_fk_reg_usr` FOREIGN KEY (`reg_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_user_fields` (
  `usf_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `usf_cat_id` int(10) unsigned NOT NULL,
  `usf_uuid` varchar(36) NOT NULL,
  `usf_type` varchar(30) NOT NULL,
  `usf_name_intern` varchar(110) NOT NULL,
  `usf_name` varchar(100) NOT NULL,
  `usf_description` text DEFAULT NULL,
  `usf_description_inline` tinyint(1) NOT NULL DEFAULT 0,
  `usf_value_list` text DEFAULT NULL,
  `usf_default_value` varchar(100) DEFAULT NULL,
  `usf_regex` varchar(100) DEFAULT NULL,
  `usf_icon` varchar(100) DEFAULT NULL,
  `usf_url` varchar(2000) DEFAULT NULL,
  `usf_system` tinyint(1) NOT NULL DEFAULT 0,
  `usf_disabled` tinyint(1) NOT NULL DEFAULT 0,
  `usf_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `usf_registration` tinyint(1) NOT NULL DEFAULT 0,
  `usf_required_input` smallint(6) NOT NULL DEFAULT 0,
  `usf_sequence` smallint(6) NOT NULL,
  `usf_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usf_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `usf_usr_id_change` int(10) unsigned DEFAULT NULL,
  `usf_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`usf_id`),
  UNIQUE KEY `admidio_idx_usf_name_intern` (`usf_name_intern`),
  UNIQUE KEY `admidio_idx_usf_uuid` (`usf_uuid`),
  KEY `admidio_fk_usf_cat` (`usf_cat_id`),
  KEY `admidio_fk_usf_usr_create` (`usf_usr_id_create`),
  KEY `admidio_fk_usf_usr_change` (`usf_usr_id_change`),
  CONSTRAINT `admidio_fk_usf_cat` FOREIGN KEY (`usf_cat_id`) REFERENCES `admidio_categories` (`cat_id`),
  CONSTRAINT `admidio_fk_usf_usr_change` FOREIGN KEY (`usf_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_usf_usr_create` FOREIGN KEY (`usf_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_roles_rights` (
  `ror_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ror_name_intern` varchar(50) NOT NULL,
  `ror_table` varchar(50) NOT NULL,
  `ror_ror_id_parent` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`ror_id`),
  KEY `admidio_fk_ror_ror_parent` (`ror_ror_id_parent`),
  CONSTRAINT `admidio_fk_ror_ror_parent` FOREIGN KEY (`ror_ror_id_parent`) REFERENCES `admidio_roles_rights` (`ror_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_user_log` (
  `usl_id` int(11) NOT NULL AUTO_INCREMENT,
  `usl_usr_id` int(10) unsigned NOT NULL,
  `usl_usf_id` int(10) unsigned NOT NULL,
  `usl_value_old` varchar(4000) DEFAULT NULL,
  `usl_value_new` varchar(4000) DEFAULT NULL,
  `usl_usr_id_create` int(10) unsigned DEFAULT NULL,
  `usl_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `usl_comment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`usl_id`),
  KEY `admidio_fk_user_log_1` (`usl_usr_id`),
  KEY `admidio_fk_user_log_2` (`usl_usr_id_create`),
  KEY `admidio_fk_user_log_3` (`usl_usf_id`),
  CONSTRAINT `admidio_fk_user_log_1` FOREIGN KEY (`usl_usr_id`) REFERENCES `admidio_users` (`usr_id`),
  CONSTRAINT `admidio_fk_user_log_2` FOREIGN KEY (`usl_usr_id_create`) REFERENCES `admidio_users` (`usr_id`),
  CONSTRAINT `admidio_fk_user_log_3` FOREIGN KEY (`usl_usf_id`) REFERENCES `admidio_user_fields` (`usf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_user_relation_types` (
  `urt_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `urt_uuid` varchar(36) NOT NULL,
  `urt_name` varchar(100) NOT NULL,
  `urt_name_male` varchar(100) NOT NULL,
  `urt_name_female` varchar(100) NOT NULL,
  `urt_edit_user` tinyint(1) NOT NULL DEFAULT 0,
  `urt_id_inverse` int(10) unsigned DEFAULT NULL,
  `urt_usr_id_create` int(10) unsigned DEFAULT NULL,
  `urt_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `urt_usr_id_change` int(10) unsigned DEFAULT NULL,
  `urt_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`urt_id`),
  UNIQUE KEY `admidio_idx_ure_urt_name` (`urt_name`),
  UNIQUE KEY `admidio_idx_urt_uuid` (`urt_uuid`),
  KEY `admidio_fk_urt_id_inverse` (`urt_id_inverse`),
  KEY `admidio_fk_urt_usr_change` (`urt_usr_id_change`),
  KEY `admidio_fk_urt_usr_create` (`urt_usr_id_create`),
  CONSTRAINT `admidio_fk_urt_id_inverse` FOREIGN KEY (`urt_id_inverse`) REFERENCES `admidio_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  CONSTRAINT `admidio_fk_urt_usr_change` FOREIGN KEY (`urt_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_urt_usr_create` FOREIGN KEY (`urt_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_rooms` (
  `room_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `room_uuid` varchar(36) NOT NULL,
  `room_name` varchar(50) NOT NULL,
  `room_description` text DEFAULT NULL,
  `room_capacity` int(11) NOT NULL,
  `room_overhang` int(11) DEFAULT NULL,
  `room_usr_id_create` int(10) unsigned DEFAULT NULL,
  `room_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `room_usr_id_change` int(10) unsigned DEFAULT NULL,
  `room_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`room_id`),
  UNIQUE KEY `admidio_idx_room_uuid` (`room_uuid`),
  KEY `admidio_fk_room_usr_create` (`room_usr_id_create`),
  KEY `admidio_fk_room_usr_change` (`room_usr_id_change`),
  CONSTRAINT `admidio_fk_room_usr_change` FOREIGN KEY (`room_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_room_usr_create` FOREIGN KEY (`room_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_ids` (
  `ids_usr_id` int(10) unsigned NOT NULL,
  `ids_reference_id` int(10) unsigned NOT NULL,
  KEY `admidio_fk_ids_usr_id` (`ids_usr_id`),
  CONSTRAINT `admidio_fk_ids_usr_id` FOREIGN KEY (`ids_usr_id`) REFERENCES `admidio_users` (`usr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_user_relations` (
  `ure_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ure_urt_id` int(10) unsigned NOT NULL,
  `ure_usr_id1` int(10) unsigned NOT NULL,
  `ure_usr_id2` int(10) unsigned NOT NULL,
  `ure_usr_id_create` int(10) unsigned DEFAULT NULL,
  `ure_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `ure_usr_id_change` int(10) unsigned DEFAULT NULL,
  `ure_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ure_id`),
  UNIQUE KEY `admidio_idx_ure_urt_usr` (`ure_urt_id`,`ure_usr_id1`,`ure_usr_id2`),
  KEY `admidio_fk_ure_usr1` (`ure_usr_id1`),
  KEY `admidio_fk_ure_usr2` (`ure_usr_id2`),
  KEY `admidio_fk_ure_usr_change` (`ure_usr_id_change`),
  KEY `admidio_fk_ure_usr_create` (`ure_usr_id_create`),
  CONSTRAINT `admidio_fk_ure_urt` FOREIGN KEY (`ure_urt_id`) REFERENCES `admidio_user_relation_types` (`urt_id`) ON DELETE CASCADE,
  CONSTRAINT `admidio_fk_ure_usr1` FOREIGN KEY (`ure_usr_id1`) REFERENCES `admidio_users` (`usr_id`) ON DELETE CASCADE,
  CONSTRAINT `admidio_fk_ure_usr2` FOREIGN KEY (`ure_usr_id2`) REFERENCES `admidio_users` (`usr_id`) ON DELETE CASCADE,
  CONSTRAINT `admidio_fk_ure_usr_change` FOREIGN KEY (`ure_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_ure_usr_create` FOREIGN KEY (`ure_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_announcements` (
  `ann_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ann_cat_id` int(10) unsigned NOT NULL,
  `ann_uuid` varchar(36) NOT NULL,
  `ann_headline` varchar(100) NOT NULL,
  `ann_description` text DEFAULT NULL,
  `ann_usr_id_create` int(10) unsigned DEFAULT NULL,
  `ann_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `ann_usr_id_change` int(10) unsigned DEFAULT NULL,
  `ann_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ann_id`),
  UNIQUE KEY `admidio_idx_ann_uuid` (`ann_uuid`),
  KEY `admidio_fk_ann_cat` (`ann_cat_id`),
  KEY `admidio_fk_ann_usr_create` (`ann_usr_id_create`),
  KEY `admidio_fk_ann_usr_change` (`ann_usr_id_change`),
  CONSTRAINT `admidio_fk_ann_cat` FOREIGN KEY (`ann_cat_id`) REFERENCES `admidio_categories` (`cat_id`),
  CONSTRAINT `admidio_fk_ann_usr_change` FOREIGN KEY (`ann_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_ann_usr_create` FOREIGN KEY (`ann_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_links` (
  `lnk_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lnk_cat_id` int(10) unsigned NOT NULL,
  `lnk_uuid` varchar(36) NOT NULL,
  `lnk_name` varchar(255) NOT NULL,
  `lnk_description` text DEFAULT NULL,
  `lnk_url` varchar(2000) NOT NULL,
  `lnk_counter` int(11) NOT NULL DEFAULT 0,
  `lnk_usr_id_create` int(10) unsigned DEFAULT NULL,
  `lnk_timestamp_create` timestamp NOT NULL DEFAULT current_timestamp(),
  `lnk_usr_id_change` int(10) unsigned DEFAULT NULL,
  `lnk_timestamp_change` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`lnk_id`),
  UNIQUE KEY `admidio_idx_lnk_uuid` (`lnk_uuid`),
  KEY `admidio_fk_lnk_cat` (`lnk_cat_id`),
  KEY `admidio_fk_lnk_usr_create` (`lnk_usr_id_create`),
  KEY `admidio_fk_lnk_usr_change` (`lnk_usr_id_change`),
  CONSTRAINT `admidio_fk_lnk_cat` FOREIGN KEY (`lnk_cat_id`) REFERENCES `admidio_categories` (`cat_id`),
  CONSTRAINT `admidio_fk_lnk_usr_change` FOREIGN KEY (`lnk_usr_id_change`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL,
  CONSTRAINT `admidio_fk_lnk_usr_create` FOREIGN KEY (`lnk_usr_id_create`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `admidio_messages_content` (
  `msc_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `msc_msg_id` int(10) unsigned NOT NULL,
  `msc_usr_id` int(10) unsigned DEFAULT NULL,
  `msc_message` text NOT NULL,
  `msc_timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`msc_id`),
  KEY `admidio_fk_msc_msg_id` (`msc_msg_id`),
  KEY `admidio_fk_msc_usr_id` (`msc_usr_id`),
  CONSTRAINT `admidio_fk_msc_msg_id` FOREIGN KEY (`msc_msg_id`) REFERENCES `admidio_messages` (`msg_id`),
  CONSTRAINT `admidio_fk_msc_usr_id` FOREIGN KEY (`msc_usr_id`) REFERENCES `admidio_users` (`usr_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

# dumping data for admidio.admidio_roles
INSERT INTO `admidio_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_dates`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (1, 4, NULL, 'e0319f9d-c848-4d4c-8f22-7a251ab5ed29', 'Administrator', 'Group of system administrators', 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2023-11-29 19:58:15', NULL, NULL, 1, 0, 1);
INSERT INTO `admidio_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_dates`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (2, 4, NULL, 'fdfdf9e6-3da5-493c-b225-203c2474bb28', 'Member', 'All organization members', 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 1, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2023-11-29 19:58:15', NULL, NULL, 1, 0, 0);
INSERT INTO `admidio_roles` (`rol_id`, `rol_cat_id`, `rol_lst_id`, `rol_uuid`, `rol_name`, `rol_description`, `rol_assign_roles`, `rol_approve_users`, `rol_announcements`, `rol_dates`, `rol_documents_files`, `rol_edit_user`, `rol_guestbook`, `rol_guestbook_comments`, `rol_mail_to_all`, `rol_mail_this_role`, `rol_photo`, `rol_profile`, `rol_weblinks`, `rol_all_lists_view`, `rol_default_registration`, `rol_leader_rights`, `rol_view_memberships`, `rol_view_members_profiles`, `rol_start_date`, `rol_start_time`, `rol_end_date`, `rol_end_time`, `rol_weekday`, `rol_location`, `rol_max_members`, `rol_cost`, `rol_cost_period`, `rol_usr_id_create`, `rol_timestamp_create`, `rol_usr_id_change`, `rol_timestamp_change`, `rol_valid`, `rol_system`, `rol_administrator`) VALUES (3, 4, NULL, 'f65bb1d6-3835-4f45-b242-c3397450ff23', 'Association&rsquo;s board', 'Administrative board of association', 0, 0, 1, 1, 0, 1, 0, 0, 1, 2, 0, 1, 1, 1, 0, 0, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2023-11-29 19:58:15', NULL, NULL, 1, 0, 0);




# dumping data for admidio.admidio_menu
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (1, NULL, NULL, 'b00cd092-1bb4-4947-b1b2-21833f6f0ef6', 'modules', 'SYS_MODULES', '', 1, 1, 1, NULL, '');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (2, NULL, NULL, '32df761d-cca7-4e4d-91c5-74310eeb75b7', 'administration', 'SYS_ADMINISTRATION', '', 1, 2, 1, NULL, '');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (3, NULL, NULL, 'ccd3cf1f-51f8-406c-a5e0-c3989a743a86', 'plugins', 'SYS_PLUGINS', '', 1, 3, 1, NULL, '');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (4, 1, NULL, '374f0405-5b22-450f-9aae-c80c7a6bba2c', 'overview', 'SYS_OVERVIEW', '', 0, 1, 1, '/adm_program/overview.php', 'fa-home');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (5, 1, 7, '134117b5-f92e-4571-aa1a-8c8a61a5b661', 'documents-files', 'SYS_DOCUMENTS_FILES', 'SYS_DOCUMENTS_FILES_DESC', 0, 3, 1, '/adm_program/modules/documents-files/documents_files.php', 'fa-file-download');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (6, 1, 10, '00e88569-5b77-4e49-ac66-1383c83da427', 'groups-roles', 'SYS_GROUPS_ROLES', 'SYS_GROUPS_ROLES_DESC', 0, 7, 1, '/adm_program/modules/groups-roles/groups_roles.php', 'fa-users');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (7, 1, 2, 'f2f3532a-bde7-48d5-a8c2-c1dd6d466a87', 'announcements', 'SYS_ANNOUNCEMENTS', 'SYS_ANNOUNCEMENTS_DESC', 0, 2, 1, '/adm_program/modules/announcements/announcements.php', 'fa-newspaper');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (8, 1, 14, '71e7ac32-f93d-4205-9512-d68215660588', 'photo', 'SYS_PHOTOS', 'PHO_PHOTOS_DESC', 0, 5, 1, '/adm_program/modules/photos/photos.php', 'fa-image');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (9, 1, 8, '96f22300-ceea-44ad-8e62-9c35dea19ec3', 'guestbook', 'GBO_GUESTBOOK', 'GBO_GUESTBOOK_DESC', 0, 6, 1, '/adm_program/modules/guestbook/guestbook.php', 'fa-book');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (10, 1, 6, 'a1c6a33c-c308-4112-87ff-0d0eabe59c02', 'dates', 'DAT_DATES', 'SYS_EVENTS_DESC', 0, 8, 1, '/adm_program/modules/dates/dates.php', 'fa-calendar-alt');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (11, 1, 5, 'bf6b44ad-4384-4804-99b9-7b1f02de94bc', 'category-report', 'SYS_CATEGORY_REPORT', 'SYS_CATEGORY_REPORT_DESC', 0, 9, 1, '/adm_program/modules/category-report/category_report.php', 'fa-list-ul');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (12, 2, 9, '5b07f2cc-1ca1-4758-8026-5ddd5c643145', 'weblinks', 'SYS_WEBLINKS', 'SYS_WEBLINKS_DESC', 0, 9, 1, '/adm_program/modules/links/links.php', 'fa-link');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (13, 2, 3, '95e6b7d5-4eca-4775-b03d-ca82c0772264', 'dbback', 'SYS_DATABASE_BACKUP', 'SYS_DATABASE_BACKUP_DESC', 0, 4, 1, '/adm_program/modules/backup/backup.php', 'fa-database');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (14, 2, 15, '09f7ea80-1d04-45a3-865b-4b831ba6ce92', 'orgprop', 'SYS_SETTINGS', 'ORG_ORGANIZATION_PROPERTIES_DESC', 0, 6, 1, '/adm_program/modules/preferences/preferences.php', 'fa-cog');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (15, 1, 12, 'c8e92f67-d5e7-40eb-823a-e4b2a2cf42f7', 'mail', 'SYS_EMAIL', 'SYS_EMAIL_DESC', 0, 4, 1, '/adm_program/modules/messages/messages_write.php', 'fa-envelope');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (16, 2, 17, '273a01ac-7cbc-407b-ab89-808bb3705e1a', 'newreg', 'SYS_NEW_REGISTRATIONS', 'SYS_MANAGE_NEW_REGISTRATIONS_DESC', 0, 1, 1, '/adm_program/modules/registration/registration.php', 'fa-address-card');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (17, 2, 11, '833c7009-3a5c-463c-ba39-333e2cef0cde', 'usrmgt', 'SYS_MEMBERS', 'SYS_MEMBERS_DESC', 0, 2, 1, '/adm_program/modules/members/members.php', 'fa-users-cog');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (18, 2, 13, 'c24d6ae9-f55a-4144-9c15-6cb5d948ac20', 'menu', 'SYS_MENU', 'SYS_MENU_DESC', 0, 5, 1, '/adm_program/modules/menu/menu.php', 'fa-stream');
INSERT INTO `admidio_menu` (`men_id`, `men_men_id_parent`, `men_com_id`, `men_uuid`, `men_name_intern`, `men_name`, `men_description`, `men_node`, `men_order`, `men_standard`, `men_url`, `men_icon`) VALUES (20, 2, 15, 'e93ac558-4b02-477b-b459-c27510152d9a', 'MITGLIEDERBEITRAEGE', 'Mitgliederbeitraege', 'Das Mitgliedsbeitrags-Plugin dient dazu, Mitgliedsbeiträge zu berechnen und diese entweder als SEPA-XML-Datei oder in Form einer Liste (XLSX, CSV) zu exportieren. Der Mitgliedsbeitrag bietet keine Möglichkeit, eine SEPA-XML-Datei direkt an eine Bank zu senden. Hierfür muss eine externe Homebanking-Anwendung verwendet werden.', 0, 6, 0, '/adm_plugins/membership_fee/membership_fee.php', 'fa-money-check-alt');


# dumping data for admidio.admidio_categories
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (1, NULL, '918ff602-869b-4abe-a2d0-60ccba022cfa', 'USF', 'BASIC_DATA', 'SYS_BASIC_DATA', 1, 0, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (2, NULL, 'af7bd452-a030-4aae-96d0-b58003c1c0f3', 'USF', 'SOCIAL_NETWORKS', 'SYS_SOCIAL_NETWORKS', 0, 0, 4, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (3, NULL, 'eba2ad5d-de8f-4dfd-86d2-a715ebce8dd5', 'USF', 'ADDIDIONAL_DATA', 'INS_ADDIDIONAL_DATA', 0, 0, 5, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (4, 1, '0bba6ad5-9ed4-44e8-8116-4e735a65da45', 'ROL', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (5, 1, '06989130-592d-4f56-ae4d-185a3e831198', 'ROL', 'GROUPS', 'INS_GROUPS', 0, 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (6, 1, '1c4a7130-63e2-4a44-800b-25c2594ac528', 'ROL', 'COURSES', 'INS_COURSES', 0, 0, 3, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (7, 1, '9b51ecae-fc82-4800-83da-1af7b1526342', 'ROL', 'TEAMS', 'INS_TEAMS', 0, 0, 4, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (8, 1, 'efe60ee9-3999-4b49-b14c-ce510502a673', 'ROL', 'EVENTS', 'SYS_EVENTS_CONFIRMATION_OF_PARTICIPATION', 1, 0, 5, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (9, 1, '5d08e40f-a8ec-43a1-a21a-c2214ac37e43', 'LNK', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (10, 1, '311f47d9-a5fe-4441-84cd-eaca9bccc55e', 'LNK', 'INTERN', 'INS_INTERN', 0, 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (11, 1, '9bc3bf00-2997-4125-80f2-f0ba8b2e9581', 'ANN', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (12, 1, '1ac3d73a-4475-4653-aa23-6099783ef620', 'ANN', 'IMPORTANT', 'SYS_IMPORTANT', 0, 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (13, 1, 'a9570247-168d-4ea4-a83b-d8847d239b86', 'DAT', 'COMMON', 'SYS_COMMON', 0, 1, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (14, 1, 'b467f61f-dcc5-4b5f-a1b5-5c836a9f4e75', 'DAT', 'TRAINING', 'INS_TRAINING', 0, 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (15, 1, '9f0469cf-66d5-423c-beb1-b7cea63ece34', 'DAT', 'COURSES', 'INS_COURSES', 0, 0, 3, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (16, 1, '4c8ca9eb-c8e4-48e6-bcac-99effd97a76a', 'USF', 'MEMBERSHIP1', 'PMB_MEMBERSHIP', 0, 0, 7, 2, '2023-12-06 19:52:22', 2, '2023-12-14 20:16:02');
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (17, 1, 'e6e03569-5890-4906-9b6d-d53c8fedd24e', 'USF', 'MEMBERSHIP_FEE1', 'PMB_MEMBERSHIP_FEE', 0, 0, 8, 2, '2023-12-06 19:52:22', 2, '2023-12-14 20:16:02');
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (18, 1, 'a93aaf30-ce03-47d3-8d83-be9c02b655f7', 'USF', 'MANDATE1', 'PMB_MANDATE', 0, 0, 9, 2, '2023-12-06 19:52:22', 2, '2023-12-14 20:16:02');
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (19, NULL, 'fa623310-5dfe-4664-8679-89f8e92d6033', 'USF', 'ACCOUNT_DATA', 'PMB_ACCOUNT_DATA', 0, 0, 6, 2, '2023-12-06 19:52:22', 2, '2023-12-14 20:17:11');
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (20, NULL, '4f6677ef-4311-4588-be93-39480806b5fd', 'USF', 'ERSTE_KONTAKTPERSON', 'Erste Kontaktperson', 0, 0, 2, 2, '2023-12-14 20:16:02', NULL, NULL);
INSERT INTO `admidio_categories` (`cat_id`, `cat_org_id`, `cat_uuid`, `cat_type`, `cat_name_intern`, `cat_name`, `cat_system`, `cat_default`, `cat_sequence`, `cat_usr_id_create`, `cat_timestamp_create`, `cat_usr_id_change`, `cat_timestamp_change`) VALUES (21, NULL, '2727a3f0-74ce-4e89-87dd-9b41cae46fe4', 'USF', 'ZWEITE_KONTAKTPERSON', 'Zweite Kontaktperson', 0, 0, 3, 2, '2023-12-14 20:16:36', NULL, NULL);




# dumping data for admidio.admidio_texts
INSERT INTO `admidio_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (1, 1, 'SYSMAIL_REGISTRATION_USER', '#subject# Registration at #organization_long_name# confirmed\r\n#content# Hello #user_first_name#,\r\n\r\nyour registration on #organization_homepage# has been confirmed.\r\n\r\nYou can now log in to the homepage with your username #user_login_name# and your password.\r\n\r\nIf you have any questions, write an email to #administrator_email#.\r\n\r\nCheers,\r\nThe administrators');
INSERT INTO `admidio_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (2, 1, 'SYSMAIL_REGISTRATION_WEBMASTER', '#subject# New registration at #organization_long_name# website\r\n#content# A new user has registered on #organization_homepage#.\r\n\r\nSurname: #user_last_name#\r\nFirst Name: #user_first_name#\r\nE-Mail: #user_email#\r\n\r\n\r\nThis message was generated automatically.');
INSERT INTO `admidio_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (3, 1, 'SYSMAIL_REFUSE_REGISTRATION', '#subject# in registration at #organization_long_name# rejected.\r\n#content#Hello #user_first_name#,\r\n\r\nyour registration at #organization_homepage# was rejected.\r\n\r\nRegistrations are accepted in general by our users. If you are a member and your registration was still rejected, it may be because you were not identified as member.\r\nTo clarify the reasons for the rejection please contact the administrator #administrator_email# from #organization_homepage#.\r\n\r\nRegards,\r\nThe administrators');
INSERT INTO `admidio_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (4, 1, 'SYSMAIL_NEW_PASSWORD', '#subject# Login data for #organization_long_name#\r\n#content# Hello #user_first_name#,\r\n\r\nYou receive your login data for the website #organization_homepage#.\r\nUsername: #user_login_name#\r\nPassword: #variable1#\r\n\r\nThe password was generated automatically,\r\nYou should change it after logging in to #organization_homepage# in your profile.\r\n\r\nCheers,\r\nThe administrators');
INSERT INTO `admidio_texts` (`txt_id`, `txt_org_id`, `txt_name`, `txt_text`) VALUES (5, 1, 'SYSMAIL_PASSWORD_RESET', '#subject# Reset password for #organization_long_name#\r\n#content# Hello #user_first_name#,\r\n\r\nWe have received a request to reset your password on #organization_homepage#.\r\n\r\nIf the request came from you, you can use the following link to reset your password and set a new one: \r\n#variable1#\r\n\r\nBest regards\r\nThe administrators');




# dumping data for admidio.admidio_category_report
INSERT INTO `admidio_category_report` (`crt_id`, `crt_org_id`, `crt_name`, `crt_col_fields`, `crt_selection_role`, `crt_selection_cat`, `crt_number_col`) VALUES (1, 1, 'General role assignment', 'p2,p1,p3,p5,r1,r3,r2', NULL, NULL, 0);




# dumping data for admidio.admidio_organizations
INSERT INTO `admidio_organizations` (`org_id`, `org_uuid`, `org_shortname`, `org_longname`, `org_org_id_parent`, `org_homepage`) VALUES (1, 'b7ba0f9f-6fc2-4552-9ed1-ce541d8a67a6', 'KemitNW', 'Kemit Network', NULL, 'http://localhost/admidio');


# dumping data for admidio.admidio_plugin_preferences
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (1, 1, 'PMB__Plugininformationen__version', '5.2.1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (2, 1, 'PMB__Plugininformationen__stand', '06.08.2023');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (3, 1, 'PMB__Altersrollen__altersrollen_token', '((*))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (4, 1, 'PMB__Altersrollen__altersrollen_offset', '0');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (5, 1, 'PMB__Familienrollen__familienrollen_beitrag', '((0))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (6, 1, 'PMB__Familienrollen__familienrollen_zeitraum', '((12))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (7, 1, 'PMB__Familienrollen__familienrollen_beschreibung', '((Familienbeitrag))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (8, 1, 'PMB__Familienrollen__familienrollen_prefix', '((Familie))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (9, 1, 'PMB__Familienrollen__familienrollen_pruefung', '(())');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (10, 1, 'PMB__Beitrag__beitrag_prefix', 'Mitgliedsbeitrag 2019');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (11, 1, 'PMB__Beitrag__beitrag_suffix', '(ant.)');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (12, 1, 'PMB__Beitrag__beitrag_textmitnam', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (13, 1, 'PMB__Beitrag__beitrag_textmitfam', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (14, 1, 'PMB__Beitrag__beitrag_text_token', '#');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (15, 1, 'PMB__Beitrag__beitrag_anteilig', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (16, 1, 'PMB__Beitrag__beitrag_abrunden', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (17, 1, 'PMB__Beitrag__beitrag_mindestbetrag', '0');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (18, 1, 'PMB__Kontodaten__bank', 'Sparkasse Musterstadt');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (19, 1, 'PMB__Kontodaten__inhaber', 'Musterverein e.V.');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (20, 1, 'PMB__Kontodaten__iban', 'DE123456789');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (21, 1, 'PMB__Kontodaten__bic', 'ABCDEFGH');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (22, 1, 'PMB__Kontodaten__ci', 'DE98ZZZ09999999999');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (23, 1, 'PMB__Kontodaten__origcreditor', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (24, 1, 'PMB__Kontodaten__origci', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (25, 1, 'PMB__Mandatsreferenz__prefix_fam', 'FAM');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (26, 1, 'PMB__Mandatsreferenz__prefix_mem', 'MIT');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (27, 1, 'PMB__Mandatsreferenz__prefix_pay', 'ZAL');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (28, 1, 'PMB__Mandatsreferenz__min_length', '15');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (29, 1, 'PMB__Mandatsreferenz__data_field', '-- User_ID --');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (30, 1, 'PMB__Rollenpruefung__altersrollenfamilienrollen', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (31, 1, 'PMB__Rollenpruefung__altersrollenpflicht', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (32, 1, 'PMB__Rollenpruefung__familienrollenpflicht', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (33, 1, 'PMB__Rollenpruefung__fixrollenpflicht', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (34, 1, 'PMB__Rollenpruefung__bezugskategorie', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (35, 1, 'PMB__Rollenpruefung__altersrollenaltersrollen', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (36, 1, 'PMB__Rollenpruefung__familienrollenfix', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (37, 1, 'PMB__Rollenpruefung__altersrollenfix', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (38, 1, 'PMB__Rollenpruefung__fixrollenfixrollen', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (39, 1, 'PMB__Rollenpruefung__age_staggered_roles_exclusion', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (40, 1, 'PMB__tests_enable__age_staggered_roles', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (41, 1, 'PMB__tests_enable__role_membership_age_staggered_roles', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (42, 1, 'PMB__tests_enable__role_membership_duty_and_exclusion', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (43, 1, 'PMB__tests_enable__family_roles', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (44, 1, 'PMB__tests_enable__account_details', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (45, 1, 'PMB__tests_enable__mandate_management', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (46, 1, 'PMB__tests_enable__iban_check', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (47, 1, 'PMB__tests_enable__bic_check', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (48, 1, 'PMB__Rechnungs-Export__rechnung_dateiname', 'rechnung');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (49, 1, 'PMB__Rechnungs-Export__rechnung_dateityp', 'xlsx');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (50, 1, 'PMB__SEPA__dateiname', 'sepa');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (51, 1, 'PMB__SEPA__kontroll_dateiname', 'sepa');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (52, 1, 'PMB__SEPA__kontroll_dateityp', 'xlsx');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (53, 1, 'PMB__SEPA__vorabinformation_dateiname', 'export');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (54, 1, 'PMB__SEPA__vorabinformation_dateityp', 'xlsx');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (55, 1, 'PMB__columnconfig__payments_fields', '((p21#_#p25#_#p24#_#p22#_#p1#_#p2#_#p9))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (56, 1, 'PMB__columnconfig__mandates_fields', '((p27#_#p26#_#p1#_#p2#_#p9))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (57, 1, 'PMB__columnconfig__bill_fields', '((p1#_#p2#_#p9))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (58, 1, 'PMB__columnconfig__duedates_fields', '((p25#_#p24#_#p22#_#p1#_#p2#_#p9))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (59, 1, 'PMB__membernumber__format', '');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (60, 1, 'PMB__membernumber__fill_gaps', '1');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (61, 1, 'PMB__access__preferences', '(())');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (62, 1, 'PMB__individual_contributions__access_to_module', '0');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (63, 1, 'PMB__individual_contributions__desc', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (64, 1, 'PMB__individual_contributions__short_desc', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (65, 1, 'PMB__individual_contributions__role', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (66, 1, 'PMB__individual_contributions__amount', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (67, 1, 'PMB__individual_contributions__profilefield', '(( ))');
INSERT INTO `admidio_plugin_preferences` (`plp_id`, `plp_org_id`, `plp_name`, `plp_value`) VALUES (68, 1, 'PMB__multiplier__roles', '(())');


# dumping data for admidio.admidio_users
INSERT INTO `admidio_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (1, '5d6a1624-a65f-47d5-9527-a53802798da7', 'System', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, 0, NULL, '2023-11-29 19:58:15', NULL, NULL, 0);
INSERT INTO `admidio_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (2, 'cd1fd384-5f90-4226-8d6e-f4bd28b73ff5', 'fhaman', '$2y$12$.N/C7N6uWQeS07w9dlFXSuxB2OMUBV/SseJSn00.QTDbSFi6jw7qa', 0xffd8ffe000104a46494600010101006000600000fffe003b43524541544f523a2067642d6a7065672076312e3020287573696e6720494a47204a50454720763830292c207175616c697479203d2039350affdb0043000201010101010201010102020202020403020202020504040304060506060605060606070908060709070606080b08090a0a0a0a0a06080b0c0b0a0c090a0a0affdb004301020202020202050303050a0706070a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0a0affc000110800aa004e03011100021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00fc0024e4f3401df7c27f037c00f15da4f73f15ff00680d47c24f6f03b7d9e0f0549a93dc482d75095521d9708a434d6fa7dbe6468f0da8b391b2dd99c03a8f057c15fd9175ad0bc41a9f8cbf6d56d12eb4df87d0ea7a269c3e1e5edcc9ac7885ede499f465647d9044924696e6f642019278d9626896492300a3fb61fc26fd96fe0dfc4bb0f0c7ec93fb5cbfc65f0ecfa043757fe286f025ef87becb7ed34caf67f66bc6323ed8d2193cd1f29f3f68e509201e4e49cf5a004c9f53401ea96df0abf6679574049ff6ad6864bdb1b593c42efe08bb31e993c92d879b146558b5c0862babc2cfb63df269b2a20293412c801cef863c03f0e7553a445e22f8e3a5e96daadb48d7327f65decd1e912f9fe546977b61dc41199ddadd67db0e3689253e4800dcf0bfc2ff00d9d2e5b5bb4f1c7ed4674fb8b0d534eb7d265d2fc1777796baa5bcb71147797224778a4844113493223c5ba6f2b66236618e79cf10b1118c61783bde57dbe56d6feba19b955551251f77abbedf23cdaed6d63982d95cc92a79684bc91043bca82c3018f01b201cf200385ce0741a1d37c36f03f817c63a67896ebc63f162cfc3173a568e973a1c37ba74b3a6a9746ea08dadd9a2cb42a2179a4dea92b178d13cb08f24d080647827c3d61e2ef1a691e14d57c5da6f87ed753d52ded2e75ed644c6cf4d8e49151ae67f223925f2a30c5dfcb8ddf6a9da8c70a403d8bc31fb1af82bc4ebe3ad7a2fdb0fe1a5b683e11d1357d4346bcbdd64417de2936b1cc6d22b2b194a4a1eee484aaa4de5cb1a659e30cf6f15c006cf8dbf627fd9cbc2ff0014fc4bf0f74cff008297fc2abeb1d17e20de78774ef100d1f5c6b6d42ce3b76920d601b7b2997ecaf30fb2b792d3b2ca7cc8fcfb622e88060fc7dfd95be10fc25d43c4ba27c3dfdacbc37e3ebaf0dd8d9decd75a1adb45637314f792426382696ec35d5c470cba6caf15b4736d37178bbb6584934801e9bf027fe09d5fb27fc5bf17781743f177fc14c7c19e12d23c57e32d6749d4bc57a9da69cb67a7e9b68658edb5616f36ad0dfc515cce2dd045a85ae9f22a5c19944b14333a00737f033f614fd9dfe28fc46d03c1be31ff008290fc33d02c3528ef24d6b554b3bb0348586f2d2da32c75216304c664b992ed1527de2ded65dea93e2de803ce3e327ecdba57c25f865a67c448be34f8535c9f57f136a3a65be85a2788b4dbdbc820b428a6eae23b4bc99edc3ca5d1372f95288cc904b3c4c923007963753f5a0028015ba9fad002500140050007ad0014005001400add4fd680128006ea7eb400500140050007ad00140050014003753f5a002803fa008ffe0893ff0004c824effd997b9e9e33d6bff932bc9face23f9bf047a5f57a3d89e0ff0082217fc13125183fb327e3ff0009a6b5ff00c9947d6711fcdf820fabd1ec588ffe0871ff0004c16ebfb31678ede34d6fff009368face23f9bf042fabd1ec4d1ffc10d7fe097857e6fd98b9f43e34d6ff00f9368face23f9bf043fabd1ec3cffc10d3fe0974b9cfecc00f1c7fc56badff00f26d1f59c47f37e083eaf47b0bff000e31ff00825de39fd987ff002f4d6fff009368face23f9bf041f57a3d863ff00c10cff00e09783eefecc07ebff0009aeb7ff00c9b4de26bf47f820fabd1ec4327fc10e7fe097e84e7f661ffcbd75bffe4da5f59c47f37e085f57a3d88dff00e0881ff04bf562a7f662efff0043a6b7ff00c9b47d6711fcdf821fd5e8f6236ff8220ffc130c1c8fd99723d3fe133d6b8ffc9da3eb388fe6fc107d5e8f63ea98e31b88cf73d3d6b1362edb427033cff5a00b91441796247b6680337c61e3af03fc39d0e5f12fc41f17e99a2e9f17facbed5afe38225ff8139033ed4d26f603e7ff001b7fc15e3f60df06dc49671fc5c93579632c36e8fa35ccaad8eeb21408c39e086229f2489728a20f087fc161ff00614f165e45673fc49bfd2de595632daa68570aa8cc32bb9915c28201e49c70738a7ece7d86a49ec7d15e0df1df81be256829e29f879e32d2f5ed3656c25f6917f1dc444f71b918807dbad46c32fcf1062460e71d7340152e6301c9f7a008581cf00d003edad768db9ce5b8cd006843005001fce803e62ff828a7fc149bc11fb166807c2be1eb68b5bf1dea16864d3f492f98ace33c09ee3072073954c82d83ca8e6ae10e7762652513f1b3e3c7ed27f1dff68bf16c9e30f8c7f11350d62f37b3c31c97188ad41e36c50a9d908c01c2819ef92735dd0a71a6ac8e7949cb738e8a064954c4e77c980c36924671dfa1ff003f4ab24d6d323d4679cca2ce5f2dfe62ac840665180c71c11d867a1247d41d9b3d37f67ffda4be3d7ecdde2f87c49f08fc6173a64f0445af6d490d04c8ac0113c672ae3e603e60082dc63a8ce74a13bb65394a3a1fafff00b037edf7e0afdb53c18f6b7b043a3f8cb4d8436b1a2acb95953207da21c9c942782a7250f07208278651717a9d0b547d01776e371563c67822a4651962672704f5a00b16d092e46de94019df15fc7ba77c28f863ad7c49d4e10f1e9560d2c7131ff5d31f9628ff00e04e5578fef5007e28fc59f85fe24f8d3f1235af897e37f18497bad6b97cf3cf3cf07eed49c9d8067e50324003b003b56919f2ab12e37259bf620d1350b002cb5e95242c642c63dc00c703049e4e074c11efcd0aacd317245e8d1d0f873fe09eba5cb27da24f124be5c30931c31a8043f5c86d9c2e7b9f5a72ad27b8d46296886afec6faa786b66ab2132c9685de412333f981f860700065e0138fef1e31d17b5974634923ce3c53e07834fbc962815d1c2305210921fa37f09e09cf047453d3a1d2351b5a89a2f7ece7f12fc5dfb3c7c71d07e29785a4ff004ad1ee3cc9609a5c7daa25c24909db8e1d4baf3c1ebd81a527cd12637e63f74bc35e27d13c79e14d2fc73e1ab91369dac69f0ded94a0e43452a0753ff7cb0ac1e868493c6739039cf340162d918370e79e4d007cb3ff00054cf8a775a6e83e1df839a5debafdbe43a9ea61060f9719d910cfa6e2e4e3fb829a03e7ef86ff000e746d56e2d6ee3d1166314256462dba3673c16c1e080493faf143dc695d9e90fe01d1348d827860670b82c809f5c7438ac9cda7634e48d8e82cd7c396363fd996689e5bfdf11c61791ce318ee7bd45dc8768ad0e4be24e8515e698d6e9106539ddb870540c74ee71e9cf2315a2859dcce4927a1f2afc54f06c1a3f886fee6f6c2f562485c43726d83f94c704f5e0fdde091d08f7cea9ea49e57e2dd3a0bad7defe04dacf083e68631aa924b03b416f98818e3232dce704d5c6cdd8947ebbffc12ff005ed47c45fb0ef8396fcc864d38ded8a173d638aea51185c7f0842a07d2a25b947b94dbd4f2c7ad48125ba90467be050da407e3f7edeffb7dd9fc4efda975dd47c2de0b9aff0046f0eb0d26d276b828258e2908793e546e1a46723247cb83c5690a7ceaf725bb33d33f663fda2f47f8a9e0fb6d4345b416f7123624b3cfcea57a9c13c03ebce41a994795d8b8cac73bfb46fedb3f137e1cfc406f07f86fe083eb70c2cd1c973034849db939c2a1e84fe43ad42a4a6ef71ca6fa1cc787bf6eaf8cb16a501f137ecf7aa69f6f73b991841709b942b10033c6a181618ce7d79f56a9a86b722edb3e93f0978997c73e1b83c4769672c767383fbbb8003a11d55c027041041ebc83827ad249df566cad2479afc66f088974eb89238515e3c35b84df93ce401d7a9c532250e547cffa8f8024956e0dedc2cbba30c23f232caa570ae5875008c1c74fc734d5fa127ea57fc131bc3971e1bfd89fc2115d2fcd76f7d72a41ea8d793053f8aa83f8d0ef7d40f6eb989b712d9fbdd7d6900ed380694a12705b9fce8d181f8fbf1186b1f0d7c7ff0012bc25e16f884fa2dc69bae32780fc3f0785fedebe2085a593cc796e8831c0cacb192aed18dbb882cc00a71b2b213f422fd8b7c3ff00148fc4cb8f156b3a3d8db6a7380352d3e00a2269805df8c31db9ce3af5fca9d4561ad4f6bf8d7a4c5e379f4db468354d327fed546f1043a3431cd77258aab1736e92ba2331f9002cc02eecfcc06d311d8728b47057ff000ffe28b7c5ed7f4ef813f12fc670f8496dede5d0ee7c7f6f15c431ca64ccd1dc2796aed88f2aa1014c904b1078d2e893e8df873e1b36be0f6b8d4747845dcaa5e79ad6c0db43bcf52a83214f4e98c9e80549b41591c9fc46f0d3ea5672a433ac455b2b2aa824f5cfd722a2577a204f9a3a9c4cbfb37dfeaf64fe22b4d6f4954b3d3a6ba5d32f2f16de4ba7854b18d1e424063d942b16e78c722af632774cfb8bf616f1a787fc6ffb297852ebc35a5b595b69f68fa7bc0f207fde42e559f700376ecefce072c46074a00f4eb93217fa9e2802bf993dbd9dcdd5b26e78e176451dd80240a00fca3d6fc4cdaa3496765114bbb990bdd5c4a006471cb127f993ede94ef703d83e16fecf4de06f04ff00c25f1fc4bf0de9a45a09237d435b488ca4ff0009c70a7f11c1a52f7b703a7f054b7fe2682e343f1fc7a26a2b2c26e349d63c33e214be80796555965d9cc6ea1d76956c11907a72be15a149391dff0083bc28e5d2dfc42efa8471f11bdc820e38c124f0de9ebc7352e4b94b50499d77c40bed0745f0f01159c6ac90e42ae0e71c63f3aceeca6d247836bda9adcab479cb1c820138c11c8f5adadadccf9f43c77e2cfc54f14786fe23e9fadfc1bf1acd6baa7866057d534596d649adf54433324b68c23575df8d8c4ca1300655be56cbd086eecfbfbf626f045b781bf66ad02c6d34a1611ea13ddea91da2b12238ae2e249225fa089a303b7031401e9578c4be319a005b22449c8cf272a7d2803f27bf6e1f86937c1ff8afe22f017d826bb4bfd4643a458c0a59e78a52244e98daaa8793d8ad095906963cb3e1c7ece5fb4278dac2111f84f5b30d94fba39ae6e336e0af4f2da574133003f83763a71de9d981f48fc07f83d79f0e124d5b5bf0eb595f5e3e2e650a56555ca8c119eb80a71d38c93deb39b491ac1595cfa0347d76df445fb32df349c6ef99b96e2a141b459cb78abc53aa6b7772c31dc606f6e7b1e78ebf851c8c4ecd58cab4d1926548cf2557966392c7bf5ad5dfa1824db3d63f62df80de17f1a784351f16fc4bd222bcb8b6d4fecbe495511ddec453e64cabf296f980f942e71cf5a06d59d8fa5e50b0810431048d0058e340005503000038000a0467dce43920e727a66801d681fccca818cf53e9401f19ff00c158be145eea5e2df047c45d2b5f1a42de2cba76a77e2d1243b5183a0f9b804866e4f64ef8c500707f0d346f8576ab0682bfb7afd9adad37b4763637da72cc72496c860d91907036f5ce31d287a00f96fecee35e6bcd27e38f88bc4ba6c8a3ca5d56086185318c3a85851f7649f41c9e0e7359ca2ef73484ba1d3c7af0b69125865129041dec720fd6a0b6d2dc88defcd244a490a492dbbbf19fe5cfd2ae0a4b715d772bdd78c6df4f66b38df33796084183b874c907a0ef5a09493665fecbbfb63fc6f9bf6def0f7eca5f0c5ec2e7c317d335cf8952eb4d2ec9b60679dd65182aca89105392bb98020e412fa19cefcc7e87ddc3245210e98e6908cdbb56594ed3c5004965b577007a74a00e2ff6a5f8436df1bbe066b9e0b361f68bd4b6375a628197f3e305805ff6986e5c7fb543696e07e5a7c327f805a219b49f13786249af0c8f1065beb88da3739046d4914b6090029c81d0f028bdd01ed1e1bd63e0ce83a7a05659038df1c7757403201d06e39c73927f0eb49deda14a565b1ccf8dbf69df86de13bd364ba8cd35c02aab6b670bcd2376f91579278ffeb8e6a630bbd513295ce4a1f8b9f15bc7faaa685e1ed2a3d0ac587efee25713dc84d9bb68218c6a412071bb9e0e0f15a35612773b7b8b28fc35e1b9679a43225ba34b757570e4492b606edc738c9209e9c6e3d691517667d1dff04a3fd8aef3e1e49ab7ed7ff13f4b9adfc4de32b4f2342d3ee71bac74a2cae24231f2bcfb22383c88e34e85d8013ba06eeee7d93a9d9898145420673c0a0473b7b188ae0ab9cf1cf3de801d6c9d403d1a8035f4ed2acefd62b8bcb48a5314a24844880ec7191b867a1e4f34ad77a8afa9e61f133fe09f9fb227c54f12dc78cbc65f06eda5d46ee4692ea7b4d42ead7ce738cb1582545dc4f24e32493934f60ba3f263f6dcf86fa6fc38fda0fc57f0f7c0da8dfe95a0695ac491d95ac5348c63800dc00766dcd8f980c93918273c55269219ce7c39d3745d2e758f4cd22d82beedfbcb3b31da5496624ee23008ebd052b81ed7e120344b99752d4d614916111b2bc8b8fbc0924f4272a3a1edde803d9ff642f838bfb5c7c546b4d5ecd5fc13e199a3b9f10bb47f2dfcbb834363ce4307dbba5f48c15f94c8a696817491fa38e029c96268022b9970eca9d79e4d00737aa463ed2c41e371c679a007408ef288e2cfccdc73401d269d6ef6d1ac6a493d589340b464ba9477afa7ceb652e27f29bc9dc71f36381ed93c501648fc70ff00829078eb45b8fdb535ff0001c968b15de9da0e9ed70ae07cf2b42778e3938cae39ef4eda5c34e63c8b48f8869a2dc25b3dbf9ec4b3a46fb8af2002700e07ddebec3d28b31dec771f0c346f887fb4278d345f859e03b45b9d575699a1b688b32471f52f34acb9da8a83731eca87033c15b0ae7ebe7ece5f02bc2dfb377c26d37e14f852569d2cd5a5d435168c2c97f7927cd35c381d37370073b5151470a2819db396ebbcfe740115c990b9018e0678cd0073dab34e2e0e24200f7a00d5d134fda3cf954839e98f7a00d6b72e7e6763ec6802c89372649c93dcf19a019f897ff056df036a16dff053af146b36778b0fdbfc37a7638c6498231c72393e5905b23e5661fc46b68eb0235b9e7bf0f7f679f89ff197c77a1fc32f02c915eeababdd18e080308fcb55deccee48dab1a80ecc72c7119f400ce83b36cfd61fd833f608f0ff00ec7ba2ea1e20d7b56b6d6bc65ad12ba8ead696fe55bdbc19522de05c0da84aab31dab92aa000140a8651f42bdd40bc3ee07271953cd201cc491bb1d477a00827521b2c79c9cfe740199a959adc481820f739fbdeff00d2803f9d41ff0005f9ff0082b4a028bfb56201e9ff00081e83ff00c835eb7d5e8f63ccf6d57b8a3fe0bf9ff056b0bb47ed5ab8cf4ff840f41ffe41a3eaf47b07b6abdc0ffc17f7fe0ada4ffc9d80c7a7fc207a0fff0020d1f57a3d83db55ee792fc67ff828b7ed8bfb41f8f22f89bf173e2e47aaeb9159a5aa5fa786f4eb626242cca0ac16e8ac4176e48279c670061aa14a2ac907b6abdc93e0effc1487f6cef805e3497e217c27f8c11e99accb66f68f7d278674cb96f25d9599409ed9d57254720038c8ce090474293e81edaaf73d55bfe0bf3ff05686fbdfb55a1faf80f41ffe41a5f57a3d83db55ee21ff0082fc7fc159d860fed54847fd885a0fff0020d1f57a3d83db55ee07fe0bf1ff0005682307f6ac5ffc21341ffe41a3eaf47b07b6abdc6b7fc17cbfe0ac849cfed56a79e73e04d07ff9068fabd1ec1edaaf710ffc17c3fe0ac27afed5087ebe04d0bff9068fab50fe50f6f57b9f1eb753f5ad8c82800a0028003d6800a002800a001ba9fad001400a49c9e6801327d6802ce9f62b7e660d7d0c3e4dbbca3ce7c79847f02fab1ec2802b64fad005ad1f4f5d5b548b4d7bc583ce62ab2b82406c1c038f5381f8d00437714705d4b04370254490aa4a060380783f8d003146e60a5f009ea7b5004da959a585e35a477d15c050a7ce81b28d95078cfa671f85004249c9e6801327d68006ea7eb4005001400500140050014005000dd4fd6800a00fffd9, NULL, NULL, NULL, '2023-12-18 22:50:46', '2023-12-19 08:45:33', 134, NULL, 0, 1, '2023-11-29 19:58:15', 2, '2023-12-05 16:38:58', 1);
INSERT INTO `admidio_users` (`usr_id`, `usr_uuid`, `usr_login_name`, `usr_password`, `usr_photo`, `usr_text`, `usr_pw_reset_id`, `usr_pw_reset_timestamp`, `usr_last_login`, `usr_actual_login`, `usr_number_login`, `usr_date_invalid`, `usr_number_invalid`, `usr_usr_id_create`, `usr_timestamp_create`, `usr_usr_id_change`, `usr_timestamp_change`, `usr_valid`) VALUES (3, '44461db3-f952-45f3-a1c1-e2ff00cab8cc', 'Test1234', '$2y$12$TYh.rSxOvebmDphD9ihwCeZxkPf74byHhddNI0xvhaWdT9z53dVCi', NULL, NULL, NULL, NULL, '2023-12-04 23:36:37', '2023-12-05 16:44:04', 2, NULL, 0, 3, '2023-12-04 23:26:12', 2, '2023-12-04 23:36:01', 1);


# dumping data for admidio.admidio_user_data
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (1, 2, 1, 'Haman');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (2, 2, 2, 'Founaboui');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (3, 2, 11, 'founaboui@gmail.com');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (4, 1, 1, 'System');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (5, 3, 1, 'TestN');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (6, 3, 2, 'TestV');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (7, 3, 11, 'founaboui@gmail.com');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (8, 3, 10, '1');
INSERT INTO `admidio_user_data` (`usd_id`, `usd_usr_id`, `usd_usf_id`, `usd_value`) VALUES (9, 3, 13, '1');


# dumping data for admidio.admidio_components
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (1, 'SYSTEM', 'Admidio Core', 'CORE', '4.2.14', 0, 350, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (2, 'MODULE', 'SYS_ANNOUNCEMENTS', 'ANNOUNCEMENTS', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (3, 'MODULE', 'SYS_DATABASE_BACKUP', 'BACKUP', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (4, 'MODULE', 'SYS_CATEGORIES', 'CATEGORIES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (5, 'MODULE', 'SYS_CATEGORY_REPORT', 'CATEGORY-REPORT', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (6, 'MODULE', 'DAT_DATES', 'DATES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (7, 'MODULE', 'SYS_DOCUMENTS_FILES', 'DOCUMENTS-FILES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (8, 'MODULE', 'GBO_GUESTBOOK', 'GUESTBOOK', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (9, 'MODULE', 'SYS_WEBLINKS', 'LINKS', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (10, 'MODULE', 'SYS_GROUPS_ROLES', 'GROUPS-ROLES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (11, 'MODULE', 'SYS_MEMBERS', 'MEMBERS', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (12, 'MODULE', 'SYS_MESSAGES', 'MESSAGES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (13, 'MODULE', 'SYS_MENU', 'MENU', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (14, 'MODULE', 'SYS_PHOTOS', 'PHOTOS', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (15, 'MODULE', 'SYS_SETTINGS', 'PREFERENCES', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (16, 'MODULE', 'PRO_PROFILE', 'PROFILE', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (17, 'MODULE', 'SYS_REGISTRATION', 'REGISTRATION', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');
INSERT INTO `admidio_components` (`com_id`, `com_type`, `com_name`, `com_name_intern`, `com_version`, `com_beta`, `com_update_step`, `com_update_completed`, `com_timestamp_installed`) VALUES (18, 'MODULE', 'SYS_ROOM_MANAGEMENT', 'ROOMS', '4.2.14', 0, 0, 1, '2023-11-29 19:58:17');


# dumping data for admidio.admidio_preferences
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (1, 1, 'enable_rss', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (2, 1, 'enable_auto_login', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (3, 1, 'default_country', 'DEU');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (4, 1, 'logout_minutes', '20');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (5, 1, 'homepage_logout', 'adm_program/overview.php');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (6, 1, 'homepage_login', 'adm_program/overview.php');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (7, 1, 'theme', 'kemit');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (8, 1, 'enable_password_recovery', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (9, 1, 'system_browser_update_check', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (10, 1, 'system_cookie_note', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (11, 1, 'system_currency', '€');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (12, 1, 'system_date', 'd.m.Y');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (13, 1, 'system_hashing_cost', '12');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (14, 1, 'system_js_editor_enabled', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (15, 1, 'system_js_editor_color', '#96c4cb');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (16, 1, 'system_language', 'de');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (17, 1, 'system_search_similar', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (18, 1, 'system_show_create_edit', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (19, 1, 'system_time', 'H:i');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (20, 1, 'system_url_imprint', 'https://kemitnetwork.net/de/impressum');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (21, 1, 'system_url_data_protection', 'https://kemitnetwork.net/de/datenschutz');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (22, 1, 'password_min_strength', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (23, 1, 'email_administrator', 'founaboui@gmail.com');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (24, 1, 'system_organization_select', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (25, 1, 'registration_enable_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (26, 1, 'enable_registration_captcha', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (27, 1, 'enable_registration_admin_mail', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (28, 1, 'registration_adopt_all_data', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (29, 1, 'mail_send_method', 'phpmail');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (30, 1, 'mail_sending_mode', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (31, 1, 'mail_recipients_with_roles', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (32, 1, 'mail_number_recipients', '50');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (33, 1, 'mail_into_to', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (34, 1, 'mail_character_encoding', 'utf-8');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (35, 1, 'mail_smtp_host', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (36, 1, 'mail_smtp_auth', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (37, 1, 'mail_smtp_port', '587');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (38, 1, 'mail_smtp_secure', 'tls');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (39, 1, 'mail_smtp_authentication_type', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (40, 1, 'mail_smtp_user', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (41, 1, 'mail_smtp_password', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (42, 1, 'system_notifications_enabled', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (43, 1, 'system_notifications_role', 'e0319f9d-c848-4d4c-8f22-7a251ab5ed29');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (44, 1, 'system_notifications_new_entries', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (45, 1, 'system_notifications_profile_changes', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (46, 1, 'captcha_type', 'pic');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (47, 1, 'captcha_fonts', 'AHGBold.ttf');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (48, 1, 'captcha_width', '215');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (49, 1, 'captcha_lines_numbers', '5');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (50, 1, 'captcha_perturbation', '0.75');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (51, 1, 'captcha_background_image', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (52, 1, 'captcha_background_color', '#B6D6DB');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (53, 1, 'captcha_text_color', '#707070');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (54, 1, 'captcha_line_color', '#707070');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (55, 1, 'captcha_charset', '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxy');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (56, 1, 'captcha_signature', 'Powered by Admidio.org');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (57, 1, 'enable_announcements_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (58, 1, 'announcements_per_page', '10');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (59, 1, 'members_enable_user_relations', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (60, 1, 'members_days_field_history', '365');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (61, 1, 'members_list_configuration', '6');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (62, 1, 'members_show_all_users', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (63, 1, 'members_users_per_page', '25');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (64, 1, 'documents_files_enable_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (65, 1, 'max_file_upload_size', '3');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (66, 1, 'enable_photo_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (67, 1, 'photo_show_mode', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (68, 1, 'photo_albums_per_page', '24');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (69, 1, 'photo_save_scale', '1000');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (70, 1, 'photo_thumbs_page', '16');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (71, 1, 'photo_thumbs_scale', '200');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (72, 1, 'photo_show_width', '1000');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (73, 1, 'photo_show_height', '750');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (74, 1, 'photo_image_text', '© localhost');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (75, 1, 'photo_image_text_size', '40');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (76, 1, 'photo_keep_original', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (77, 1, 'photo_download_enabled', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (78, 1, 'enable_guestbook_module', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (79, 1, 'guestbook_entries_per_page', '10');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (80, 1, 'enable_guestbook_captcha', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (81, 1, 'flooding_protection_time', '60');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (82, 1, 'enable_gbook_comments4all', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (83, 1, 'enable_intial_comments_loading', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (84, 1, 'enable_guestbook_moderation', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (85, 1, 'groups_roles_default_configuration', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (86, 1, 'groups_roles_enable_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (87, 1, 'groups_roles_export', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (88, 1, 'groups_roles_edit_lists', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (89, 1, 'groups_roles_members_per_page', '25');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (90, 1, 'groups_roles_show_former_members', '2');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (91, 1, 'enable_mail_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (92, 1, 'enable_pm_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (93, 1, 'enable_mail_captcha', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (94, 1, 'mail_delivery_confirmation', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (95, 1, 'mail_html_registered_users', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (96, 1, 'mail_max_receiver', '10');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (97, 1, 'mail_save_attachments', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (98, 1, 'mail_send_to_all_addresses', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (99, 1, 'mail_sendmail_address', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (100, 1, 'mail_sendmail_name', '');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (101, 1, 'mail_show_former', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (102, 1, 'mail_template', 'default.html');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (103, 1, 'max_email_attachment_size', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (104, 1, 'enable_ecard_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (105, 1, 'ecard_thumbs_scale', '250');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (106, 1, 'ecard_card_picture_width', '400');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (107, 1, 'ecard_card_picture_height', '250');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (108, 1, 'ecard_template', 'postcard.tpl');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (109, 1, 'profile_log_edit_fields', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (110, 1, 'profile_show_map_link', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (111, 1, 'profile_show_roles', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (112, 1, 'profile_show_former_roles', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (113, 1, 'profile_show_extern_roles', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (114, 1, 'profile_photo_storage', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (115, 1, 'enable_dates_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (116, 1, 'dates_per_page', '10');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (117, 1, 'dates_view', 'detail');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (118, 1, 'dates_show_map_link', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (119, 1, 'dates_show_rooms', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (120, 1, 'enable_dates_ical', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (121, 1, 'dates_ical_days_past', '30');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (122, 1, 'dates_ical_days_future', '365');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (123, 1, 'dates_default_list_configuration', '5');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (124, 1, 'dates_save_all_confirmations', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (125, 1, 'dates_may_take_part', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (126, 1, 'category_report_enable_module', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (127, 1, 'category_report_default_configuration', '1');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (128, 1, 'enable_weblinks_module', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (129, 1, 'weblinks_per_page', '0');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (130, 1, 'weblinks_redirect_seconds', '10');
INSERT INTO `admidio_preferences` (`prf_id`, `prf_org_id`, `prf_name`, `prf_value`) VALUES (131, 1, 'weblinks_target', '_blank');


# dumping data for admidio.admidio_lists
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (1, 1, 1, '9cbecb3d-a4c6-4039-ac70-f85325cbb604', 'Address list', '2023-11-29 19:58:15', 1);
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (2, 1, 1, '40e945bc-cae1-4ba5-88ad-0b0658f042db', 'Phone list', '2023-11-29 19:58:15', 1);
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (3, 1, 1, '1b7d6760-f814-40df-bc3e-af4fef60c6fa', 'Contact information', '2023-11-29 19:58:15', 1);
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (4, 1, 1, '69511102-b154-4994-bcf2-7729e33f59c1', 'Membership', '2023-11-29 19:58:15', 1);
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (5, 1, 1, '2a6d2486-f909-4595-b0f9-a0c21ef9dd87', 'Members', '2023-11-29 19:58:15', 1);
INSERT INTO `admidio_lists` (`lst_id`, `lst_org_id`, `lst_usr_id`, `lst_uuid`, `lst_name`, `lst_timestamp`, `lst_global`) VALUES (6, 1, 1, 'd73e85bc-bba6-473d-b14b-297a7c97cf96', 'Members', '2023-11-29 19:58:15', 1);






# dumping data for admidio.admidio_roles_rights_data
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (1, 5, 1, 19, 2, '2023-12-06 19:51:37');
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (2, 5, 3, 19, 2, '2023-12-06 19:51:37');
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (3, 5, 1, 20, 2, '2023-12-06 20:07:03');
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (4, 5, 3, 20, 2, '2023-12-06 20:07:03');
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (5, 3, 2, 20, 2, '2023-12-14 20:16:02');
INSERT INTO `admidio_roles_rights_data` (`rrd_id`, `rrd_ror_id`, `rrd_rol_id`, `rrd_object_id`, `rrd_usr_id_create`, `rrd_timestamp_create`) VALUES (6, 3, 2, 21, 2, '2023-12-14 20:16:36');




# dumping data for admidio.admidio_folders
INSERT INTO `admidio_folders` (`fol_id`, `fol_org_id`, `fol_fol_id_parent`, `fol_uuid`, `fol_type`, `fol_name`, `fol_description`, `fol_path`, `fol_locked`, `fol_public`, `fol_usr_id`, `fol_timestamp`) VALUES (1, 1, NULL, 'd3a2c692-5d61-435e-851c-6e841921d527', 'DOCUMENTS', 'documents_kemitnw', NULL, '/adm_my_files', 0, 1, 1, '2023-11-29 19:58:15');




# dumping data for admidio.admidio_members
INSERT INTO `admidio_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (1, 1, 2, '794512be-7694-4e54-81bf-0f6526459e9d', '2023-11-29', '9999-12-31', 0, 1, '2023-11-29 19:58:15', NULL, NULL, NULL, NULL, 0);
INSERT INTO `admidio_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (2, 2, 2, 'd14af295-e355-4981-bca9-10ef6e7ce45d', '2023-11-29', '9999-12-31', 1, 1, '2023-11-29 19:58:15', 2, '2023-12-17 16:52:25', NULL, NULL, 0);
INSERT INTO `admidio_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (3, 2, 3, '3d1a000d-4ffb-4b4f-b712-2d4bc7a1d713', '2023-12-04', '9999-12-31', 0, 2, '2023-12-04 23:31:17', NULL, NULL, NULL, NULL, 0);
INSERT INTO `admidio_members` (`mem_id`, `mem_rol_id`, `mem_usr_id`, `mem_uuid`, `mem_begin`, `mem_end`, `mem_leader`, `mem_usr_id_create`, `mem_timestamp_create`, `mem_usr_id_change`, `mem_timestamp_change`, `mem_approved`, `mem_comment`, `mem_count_guests`) VALUES (4, 3, 2, '8341a0b1-8def-4dd8-b7e6-6e5d4de29629', '2023-12-17', '9999-12-31', 1, 2, '2023-12-17 16:52:25', NULL, NULL, NULL, NULL, 0);






# dumping data for admidio.admidio_sessions
INSERT INTO `admidio_sessions` (`ses_id`, `ses_usr_id`, `ses_org_id`, `ses_session_id`, `ses_begin`, `ses_timestamp`, `ses_ip_address`, `ses_binary`, `ses_reload`) VALUES (41, 2, 1, 'ilku22shme9ro4ures4hc8o2bd', '2023-12-19 08:45:16', '2023-12-19 08:57:57', ':XXXX:XXXX', NULL, 0);


# dumping data for admidio.admidio_list_columns
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (1, 1, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (2, 1, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (3, 1, 3, 9, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (4, 1, 4, 3, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (5, 1, 5, 4, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (6, 1, 6, 5, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (7, 2, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (8, 2, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (9, 2, 3, 7, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (10, 2, 4, 8, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (11, 2, 5, 11, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (12, 3, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (13, 3, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (14, 3, 3, 9, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (15, 3, 4, 3, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (16, 3, 5, 4, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (17, 3, 6, 5, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (18, 3, 7, 7, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (19, 3, 8, 8, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (20, 3, 9, 11, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (21, 4, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (22, 4, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (23, 4, 3, 9, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (24, 4, 4, NULL, 'mem_begin', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (25, 4, 5, NULL, 'mem_end', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (26, 5, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (27, 5, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (28, 5, 3, NULL, 'mem_approved', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (29, 5, 4, NULL, 'mem_comment', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (30, 5, 5, NULL, 'mem_count_guests', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (31, 6, 1, 1, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (32, 6, 2, 2, NULL, 'ASC', NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (33, 6, 3, NULL, 'usr_login_name', NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (34, 6, 4, 10, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (35, 6, 5, 9, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (36, 6, 6, 5, NULL, NULL, NULL);
INSERT INTO `admidio_list_columns` (`lsc_id`, `lsc_lst_id`, `lsc_number`, `lsc_usf_id`, `lsc_special_field`, `lsc_sort`, `lsc_filter`) VALUES (37, 6, 7, NULL, 'usr_timestamp_change', NULL, NULL);




# dumping data for admidio.admidio_user_fields
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (1, 1, 'b7622250-a91d-431a-be9e-28fdb65abd7a', 'TEXT', 'LAST_NAME', 'SYS_LASTNAME', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (2, 1, '6aad725c-5533-464f-86b1-a7f6fddfb565', 'TEXT', 'FIRST_NAME', 'SYS_FIRSTNAME', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 1, 0, 1, 1, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (3, 1, '1b395a1c-6c5b-4239-87cf-a4dba918033b', 'TEXT', 'STREET', 'SYS_STREET', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, 3, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:40:16');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (4, 1, '25c31e2c-9e4a-4285-8e48-d1a939ca8d70', 'TEXT', 'POSTCODE', 'SYS_POSTCODE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, 4, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:41:04');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (5, 1, 'fa4f6ad9-3316-4c8b-bb35-7c283b0733d1', 'TEXT', 'CITY', 'SYS_CITY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, 5, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:42:08');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (6, 1, '5ac3b6a7-dad0-4cca-a4de-7be5cdfb5965', 'TEXT', 'COUNTRY', 'SYS_COUNTRY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, 6, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:42:32');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (7, 1, '726cd804-e01a-4f2a-ac72-2ce8dbf3ebf6', 'PHONE', 'PHONE', 'SYS_PHONE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 2, 7, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:43:32');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (8, 1, '06c1abcd-a34d-4dc7-9927-b41a7bbc95d7', 'PHONE', 'MOBILE', 'SYS_MOBILE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, 0, 8, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:44:11');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (9, 1, '9bc350c2-2ce3-4a36-bc6f-9fe73af7da85', 'DATE', 'BIRTHDAY', 'SYS_BIRTHDAY', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 0, 1, 1, 10, 1, '2023-11-29 19:58:15', 2, '2023-12-05 20:44:54');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (10, 1, 'a060655c-9aa1-4d23-986d-78e6b72816a3', 'RADIO_BUTTON', 'GENDER', 'SYS_GENDER', NULL, 0, 'fa-mars|SYS_MALE\nfa-venus|SYS_FEMALE\nfa-mars-stroke-v|SYS_DIVERSE', NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 11, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (11, 1, 'b28a1551-e033-448d-9ed4-76969b06313a', 'EMAIL', 'EMAIL', 'SYS_EMAIL', NULL, 0, NULL, NULL, NULL, NULL, NULL, 1, 0, 0, 1, 2, 12, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (12, 1, '80d60859-e0db-4e64-b9ee-6412fbd67b52', 'URL', 'WEBSITE', 'SYS_WEBSITE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 13, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (13, 3, 'bb0e70e3-efb0-4ea3-a105-fd9a5bb0eeb8', 'CHECKBOX', 'DATA_PROTECTION_PERMISSION', 'SYS_DATA_PROTECTION_PERMISSION', '<p> </p>\n\n<p> </p>\n', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 2, 13, 1, '2023-11-29 19:58:15', 2, '2023-12-10 20:00:38');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (14, 2, '7cdfb479-7580-4c99-a883-05dc30197e9f', 'TEXT', 'FACEBOOK', 'INS_FACEBOOK', 'Would you like to set a link to your Facebook profile? Your Facebook login name is required. Log in to your Facebook account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Facebook profile directly.', 0, NULL, NULL, NULL, 'fab fa-facebook', 'https://www.facebook.com/#user_content#', 0, 0, 0, 0, 0, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (15, 2, 'dbb63a46-7054-4e34-aa80-d6890692e154', 'TEXT', 'ICQ', 'INS_ICQ', 'Enter your ICQ number here. If your status can be shown on the web (enabled in Skype), it will be displayed in your profile.', 0, NULL, NULL, NULL, 'icq.png', 'https://www.icq.com/people/#user_content#', 0, 0, 0, 0, 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (16, 2, '5cd62c94-e9ba-4d8b-882e-543c50b17a9d', 'TEXT', 'SKYPE', 'INS_SKYPE', 'Enter your exact Skype name here. If your status can be shown on the web (enabled in ICQ), it will be displayed in your profile.', 0, NULL, NULL, NULL, 'fab fa-skype', NULL, 0, 0, 0, 0, 0, 3, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (17, 2, '75490d75-fbfd-491c-9b14-a21979cba534', 'TEXT', 'TWITTER', 'INS_TWITTER', 'Would you like to set a link to your X (Twitter) profile? Your X (Twitter) login name is required. Log in to your X (Twitter) account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your X (Twitter) profile directly.', 0, NULL, NULL, NULL, 'fab fa-twitter', 'https://twitter.com/#user_content#', 0, 0, 0, 0, 0, 4, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (18, 2, '577ef55f-ceb8-4238-8d80-ee61698fdfb2', 'TEXT', 'XING', 'INS_XING', 'Would you like to set a link to your Xing profile? Your Xing login name is required. Log in to your Xing account and display your profile. Copy URL in this field and save your profile here. Visitors of your profile are now able to open your Xing profile directly.', 0, NULL, NULL, NULL, 'fab fa-xing', 'https://www.xing.com/profile/#user_content#', 0, 0, 0, 0, 0, 5, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (19, 16, '4acb6013-ad9e-4f08-add3-bd278f71798a', 'TEXT', 'MEMBERNUMBER1', 'PMB_MEMBERNUMBER', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 1, 2, '2023-12-06 19:52:22', 2, '2023-12-18 21:45:39');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (20, 16, '0d615770-f7a9-41f2-981b-f1bc639ac8c4', 'DATE', 'ACCESSION1', 'PMB_ACCESSION', 'Das Beitrittsdatum zum Verein', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 2, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (21, 17, '6bb84b40-d47f-45df-a754-2615d60eb4d9', 'DATE', 'PAID1', 'PMB_PAID', 'Datumsangabe, ob und wann der Beitrag bezahlt wurde', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 1, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (22, 17, '693d8f72-197f-4900-b8fd-ecd0f926e89f', 'DECIMAL', 'FEE1', 'PMB_FEE', 'Der errechnete Mitgliedsbeitrag', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 2, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (23, 17, 'a4fcd999-4e73-4dc9-ab37-96ac92359e9b', 'TEXT', 'CONTRIBUTORY_TEXT1', 'PMB_CONTRIBUTORY_TEXT', 'Verwendungszweck', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 3, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (24, 17, 'b4f94e1e-9de7-4205-8d53-4f076faea79b', 'TEXT', 'SEQUENCETYPE1', 'PMB_SEQUENCETYPE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 4, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (25, 17, 'd1d6ebf5-e231-4e9d-98f3-7deb455dbdf0', 'DATE', 'DUEDATE1', 'PMB_DUEDATE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 5, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (26, 18, 'c3fe06da-0e5f-4364-81e9-d0f4001c187c', 'TEXT', 'MANDATEID1', 'PMB_MANDATEID', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 1, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (27, 18, 'a7a370ba-6dd2-47c4-b8a9-84b9e92bb053', 'DATE', 'MANDATEDATE1', 'PMB_MANDATEDATE', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 2, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (28, 18, '09b0e7a5-9aca-4dbe-9985-254836a3822f', 'TEXT', 'ORIG_MANDATEID1', 'PMB_ORIG_MANDATEID', 'Wird durch das Modul Mandatsänderung automatisch befüllt.', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 3, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (29, 19, '53b62946-eacc-4b89-a855-f42dbbbd6aa2', 'TEXT', 'IBAN', 'PMB_IBAN', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 1, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (30, 19, '16b5c437-015a-4ebb-87d8-21ded4cababf', 'TEXT', 'BIC', 'PMB_BIC', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 2, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (31, 19, '605adc01-429d-462f-a2a5-70cb402f2b41', 'TEXT', 'BANK', 'PMB_BANK', 'Der Name der Bank für den Bankeinzug', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 3, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (32, 19, 'b7912c1d-2248-4cb8-8ff2-7f23191c3cff', 'TEXT', 'DEBTOR', 'PMB_DEBTOR', '<p>Inhaber der angegebenen Bankverbindung.</p><p>Ein Eintrag ist nur erforderlich, wenn der Inhaber der Bankverbindung und das Mitglied nicht identisch sind. Wenn das Feld belegt ist, dann müssen KtoInh-Straße, KtoInh-PLZ und KtoInh-Ort ausgefüllt sein.</p>', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 4, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (33, 19, 'dcfdc67d-d962-4838-bd05-26bb1c43f877', 'TEXT', 'DEBTOR_STREET', 'PMB_DEBTOR_STREET', 'Adresse des Kontoinhabers.Eine Angabe ist zwingend erforderlich, wenn der Inhaber der Bankverbindung und das Mitglied nicht identisch sind.', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 5, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (34, 19, '3fd4c6b9-4dca-43c6-8b4e-63c7ac3d9a69', 'TEXT', 'DEBTOR_POSTCODE', 'PMB_DEBTOR_POSTCODE', 'PLZ des Kontoinhabers.Eine Angabe ist zwingend erforderlich, wenn der Inhaber der Bankverbindung und das Mitglied nicht identisch sind.', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 6, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (35, 19, 'd333ae7f-81f7-4322-99af-c239cca46cae', 'TEXT', 'DEBTOR_CITY', 'PMB_DEBTOR_CITY', 'Wohnort des Kontoinhabers.Eine Angabe ist zwingend erforderlich, wenn der Inhaber der Bankverbindung und das Mitglied nicht identisch sind.', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 7, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (36, 19, '6c9c22d2-c423-4900-ae4b-35044eb608e2', 'TEXT', 'DEBTOR_EMAIL', 'PMB_DEBTOR_EMAIL', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 1, 0, 0, 8, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (37, 19, 'c701c015-9181-451f-a202-a46e4ef160cb', 'TEXT', 'ORIG_DEBTOR_AGENT', 'PMB_ORIG_DEBTOR_AGENT', 'Wird durch das Modul Mandatsänderung automatisch befüllt.', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 9, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (38, 19, '547c9d48-a604-42f5-b1c5-545bfa89524e', 'TEXT', 'ORIG_IBAN', 'PMB_ORIG_IBAN', 'Wird durch das Modul Mandatsänderung automatisch befüllt.', 0, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 0, 0, 10, 2, '2023-12-06 19:52:22', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (39, 3, 'ca6abd13-8198-4840-9e8a-783da5843a5a', 'CHECKBOX', 'SYS_TERM_READ', 'SYS_TERM_READ', '<p>Ich bestätige hiermit die Nutzungsbedingungen gelesen zu haben.</p>\n', 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 1, 2, 2, '2023-12-10 19:51:00', 2, '2023-12-10 20:21:39');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (41, 20, '462e62b2-188a-4bd6-97ee-fd20ad12e034', 'TEXT', 'SYS_CONTACT_NAME_1', 'SYS_CONTACT_LAST_NAME_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 1, 2, '2023-12-14 20:09:18', 2, '2023-12-17 17:06:34');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (42, 20, '2e08c2e3-a998-4d6e-aa10-89528716c680', 'TEXT', 'SYS_CONTACT_FIRST_NAME_1', 'SYS_CONTACT_FIRST_NAME_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 2, 2, '2023-12-15 21:38:20', 2, '2023-12-17 17:07:00');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (43, 20, '5874bc53-f952-42c1-8da1-83cfe98d1d3e', 'EMAIL', 'SYS_CONTACT_EMAIL_1', 'SYS_CONTACT_EMAIL_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 3, 2, '2023-12-15 21:40:22', 2, '2023-12-17 17:07:17');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (44, 20, '96e0a908-9252-46a5-a7dd-b10f8b4da53e', 'PHONE', 'SYS_CONTACT_PHONE_1', 'SYS_CONTACT_PHONE_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 4, 2, '2023-12-15 21:41:22', 2, '2023-12-17 17:08:37');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (45, 20, 'ad93093d-5487-4eac-b31c-88187b8406c6', 'TEXT', 'SYS_CONTACT_CITY_1', 'SYS_CONTACT_CITY_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 6, 2, '2023-12-15 22:01:22', 2, '2023-12-17 17:08:04');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (46, 20, '3ca98216-7b38-4e42-9d1f-c1b3621b3ad1', 'DROPDOWN', 'SYS_CONTACT_COUNTRY_1', 'SYS_CONTACT_COUNTRY_1', NULL, 0, 'Deutschland\r\nFrankreich\r\nGroßbretanien\r\nKamerun\r\nItalien\r\nSpanien', NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 7, 2, '2023-12-15 22:04:01', 2, '2023-12-17 17:07:41');
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (47, 21, 'df1c1d19-dd43-4728-8071-b2c01013635b', 'TEXT', 'SYS_CONTACT_NAME_2', 'SYS_CONTACT_LAST_NAME_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 1, 2, '2023-12-17 17:02:58', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (48, 21, '3b088424-7edf-4701-ab1b-552c7754c8d8', 'TEXT', 'SYS_CONTACT_FIRST_NAME_2', 'SYS_CONTACT_FIRST_NAME_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 2, 2, '2023-12-17 17:13:04', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (49, 21, '78427602-6e92-46a6-be6d-c203ab724746', 'PHONE', 'SYS_CONTACT_PHONE_2', 'SYS_CONTACT_PHONE_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 3, 2, '2023-12-17 17:13:50', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (50, 20, '8760fe5e-c5af-469f-a2bd-aa84dd4c4d3a', 'TEXT', 'SYS_CONTACT_STREET_1', 'SYS_CONTACT_STREET_1', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 5, 2, '2023-12-17 17:15:02', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (51, 21, 'c8706146-7c78-4e55-bb13-89cc043ac7eb', 'EMAIL', 'SYS_CONTACT_EMAIL_2', 'SYS_CONTACT_EMAIL_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 4, 2, '2023-12-17 17:17:34', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (52, 21, '5be31194-9171-4a22-bd58-738814f27035', 'TEXT', 'SYS_CONTACT_CITY_2', 'SYS_CONTACT_CITY_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 6, 2, '2023-12-17 17:18:03', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (53, 21, 'b02edcce-423b-4448-a98f-9533a56aa997', 'DROPDOWN', 'SYS_CONTACT_COUNTRY_2', 'SYS_CONTACT_COUNTRY_2', NULL, 0, 'Deutschland\r\nFrankreich\r\nItalien\r\nSpanien\r\nEngland\r\nNorwegen\r\nDänemark,Schweden', NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 7, 2, '2023-12-17 17:19:32', NULL, NULL);
INSERT INTO `admidio_user_fields` (`usf_id`, `usf_cat_id`, `usf_uuid`, `usf_type`, `usf_name_intern`, `usf_name`, `usf_description`, `usf_description_inline`, `usf_value_list`, `usf_default_value`, `usf_regex`, `usf_icon`, `usf_url`, `usf_system`, `usf_disabled`, `usf_hidden`, `usf_registration`, `usf_required_input`, `usf_sequence`, `usf_usr_id_create`, `usf_timestamp_create`, `usf_usr_id_change`, `usf_timestamp_change`) VALUES (54, 21, 'e0e610d8-b2f8-445c-a36f-cd057cf1120c', 'TEXT', 'SYS_CONTACT_STREET_2', 'SYS_CONTACT_STREET_2', NULL, 0, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 1, 3, 5, 2, '2023-12-17 17:19:59', NULL, NULL);


# dumping data for admidio.admidio_roles_rights
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (1, 'folder_view', 'adm_folders', NULL);
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (2, 'folder_upload', 'adm_folders', NULL);
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (3, 'category_view', 'adm_categories', NULL);
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (4, 'event_participation', 'adm_dates', NULL);
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (5, 'menu_view', 'adm_menu', NULL);
INSERT INTO `admidio_roles_rights` (`ror_id`, `ror_name_intern`, `ror_table`, `ror_ror_id_parent`) VALUES (6, 'category_edit', 'adm_categories', 3);


# dumping data for admidio.admidio_user_log
INSERT INTO `admidio_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (1, 3, 10, NULL, '1', 2, '2023-12-04 23:36:01', NULL);
INSERT INTO `admidio_user_log` (`usl_id`, `usl_usr_id`, `usl_usf_id`, `usl_value_old`, `usl_value_new`, `usl_usr_id_create`, `usl_timestamp_create`, `usl_comment`) VALUES (2, 3, 13, NULL, '1', 2, '2023-12-04 23:36:01', NULL);


# dumping data for admidio.admidio_user_relation_types
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (1, 'dc01f925-9d59-4894-be6d-c166485bb4ce', 'Parent', 'Father', 'Mother', 0, 2, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (2, '414d1b4b-c0e7-4663-a6a8-01f220ec6de3', 'Child', 'Son', 'Daughter', 0, 1, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (3, 'ba430016-feba-4af2-9d50-75b88b303f14', 'Sibling', 'Brother', 'Sister', 0, 3, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (4, '43df44b6-caca-4aed-b8e0-9a4f392f3ead', 'Spouse', 'Husband', 'Wife', 0, 4, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (5, 'd04c4221-291e-47d3-a872-f870a1c9b8bf', 'Partner', 'Partner', 'Partner', 0, 5, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (6, '07e099e7-95fc-4b47-9737-d51e896f055f', 'Friend', 'Friend', 'Girlfriend', 0, 6, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (7, '78d21c9c-8a55-43e8-abf5-918cbe78e231', 'Boss', 'Boss', 'Female superior', 0, 8, 1, '2023-11-29 19:58:15', NULL, NULL);
INSERT INTO `admidio_user_relation_types` (`urt_id`, `urt_uuid`, `urt_name`, `urt_name_male`, `urt_name_female`, `urt_edit_user`, `urt_id_inverse`, `urt_usr_id_create`, `urt_timestamp_create`, `urt_usr_id_change`, `urt_timestamp_change`) VALUES (8, 'd6d1d158-efac-4e63-8d48-355a66d0fb73', 'Subordinate', 'Male subordinate', 'Female subordinate', 0, 7, 1, '2023-11-29 19:58:15', NULL, NULL);


# dumping data for admidio.admidio_rooms
INSERT INTO `admidio_rooms` (`room_id`, `room_uuid`, `room_name`, `room_description`, `room_capacity`, `room_overhang`, `room_usr_id_create`, `room_timestamp_create`, `room_usr_id_change`, `room_timestamp_change`) VALUES (1, 'f3792cfa-ddc4-4bf2-9f3d-078555221a52', 'Conference room', 'Meetings can take place here. Room has to be reserved before. Beamer is free for use.', 15, NULL, 1, '2023-11-29 19:58:15', NULL, NULL);




# dumping data for admidio.admidio_user_relations
INSERT INTO `admidio_user_relations` (`ure_id`, `ure_urt_id`, `ure_usr_id1`, `ure_usr_id2`, `ure_usr_id_create`, `ure_timestamp_create`, `ure_usr_id_change`, `ure_timestamp_change`) VALUES (1, 2, 2, 3, 2, '2023-12-09 16:46:48', NULL, NULL);
INSERT INTO `admidio_user_relations` (`ure_id`, `ure_urt_id`, `ure_usr_id1`, `ure_usr_id2`, `ure_usr_id_create`, `ure_timestamp_create`, `ure_usr_id_change`, `ure_timestamp_change`) VALUES (2, 1, 3, 2, 2, '2023-12-09 16:46:48', NULL, NULL);








SET FOREIGN_KEY_CHECKS=1;

